# -*- coding: utf-8 -*-
"""
Created on Fri Dec  3 14:32:07 2021

@author: ramon
"""

from pycoingecko import CoinGeckoAPI
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import scipy as sp

cg = CoinGeckoAPI()

def get_data(cryptocurrency):
    cryptocurrency_data = cg.get_coin_by_id(cryptocurrency, market_data='true', sparkline='true')
    df = pd.DataFrame.from_dict(cryptocurrency_data, orient='index')
    df.to_csv(r'cryptocurrency_data.csv')
    return df

get_data('bitcoin')

get_data('ethereum')

get_data('shiba-inu')

get_data('dogecoin')

#get_data('xrp')

def get_historical_data(cryptocurrency, fiat_currency, number_of_days):
    historic_price = cg.get_coin_market_chart_by_id(cryptocurrency, fiat_currency, number_of_days)
    prices = [price[1] for price in historic_price['prices']]
    return prices
print(get_historical_data('bitcoin', 'USD', 5))

ethereum = get_historical_data('ethereum', 'USD', 30)

#Bitcoin historical pricing and visualization
bitcoin = get_historical_data('bitcoin', 'USD', 365)

bt_df = pd.DataFrame(bitcoin, columns = ['Bitcoin Value'])
bt_df.index.name = 'Every Hour Count in the Past 365 Days'
bt_df.to_csv(r'Bitcoin.csv')
bt_df = pd.read_csv("Bitcoin.csv")

bt_df.plot(x = 'Every Hour Count in the Past 365 Days', y = 'Bitcoin Value', kind = 'scatter')
plt.xlabel('Every Hour Count in the Past 365 Days')
plt.ylabel('Bitcoin Value')
plt.show()

#ETH historical and visuals
eth = get_historical_data('ethereum', 'USD', 365)

eth_df = pd.DataFrame(eth, columns = ['ETH Value'])
eth_df.index.name = 'Every Hour Count in the Past 365 Days'
eth_df.to_csv(r'ETH.csv')
eth_df = pd.read_csv("ETH.csv")

eth_df.plot(x = 'Every Hour Count in the Past 365 Days', y = 'ETH Value', kind = 'scatter')
plt.xlabel('Every Hour Count in the Past 365 Days')
plt.ylabel('ETH Value')
plt.show()


#Shib historical and visuals
shib = get_historical_data('shiba-inu', 'USD', 365)

shib_df = pd.DataFrame(shib, columns = ['Shib Value'])
shib_df.index.name = 'Every Hour Count in the Past 365 Days'
shib_df.to_csv(r'shib.csv')
shib_df = pd.read_csv("shib.csv")

shib_df.plot(x = 'Every Hour Count in the Past 365 Days', y = 'Shib Value', kind = 'scatter')
plt.xlabel('Every Hour Count in the Past 365 Days')
plt.ylabel('Shib Value')
plt.show()

#Doge historical and visuals
doge = get_historical_data('dogecoin', 'USD', 365)

doge_df = pd.DataFrame(doge, columns = ['Doge Value'])
doge_df.index.name = 'Every Hour Count in the Past 365 Days'
doge_df.to_csv(r'doge.csv')
doge_df = pd.read_csv("doge.csv")

doge_df.plot(x = 'Every Hour Count in the Past 365 Days', y = 'Doge Value', kind = 'scatter')
plt.xlabel('Every Hour Count in the Past 365 Days')
plt.ylabel('Doge Value')
plt.show()

#getting more granualr data for coins
bit_hist=cg.get_coin_market_chart_range_by_id(id='bitcoin', vs_currency='usd',include_market_cap='true', include_24hr_vol='true', include_24hr_change='true',from_timestamp=1606194000,to_timestamp=1639058407)
eth_hist=cg.get_coin_market_chart_range_by_id(id='ethereum', vs_currency='usd',include_market_cap='true', include_24hr_vol='true', include_24hr_change='true',from_timestamp=1606194000,to_timestamp=1639058407)
doge_hist=cg.get_coin_market_chart_range_by_id(id='dogecoin', vs_currency='usd',include_market_cap='true', include_24hr_vol='true', include_24hr_change='true',from_timestamp=1606194000,to_timestamp=1639058407)
shib_hist=cg.get_coin_market_chart_range_by_id(id='shiba-inu', vs_currency='usd',include_market_cap='true', include_24hr_vol='true', include_24hr_change='true',from_timestamp=1606194000,to_timestamp=1639058407)

df_bit_hist = pd.DataFrame(bit_hist)
df_eth_hist = pd.DataFrame(eth_hist)
df_shib_hist = pd.DataFrame(shib_hist)
df_doge_hist = pd.DataFrame(doge_hist)


df_bit_hist.to_csv(r'bit_hist.csv')
df_eth_hist.to_csv(r'eth_hist.csv')
df_shib_hist.to_csv(r'shib_hist.csv')
df_doge_hist.to_csv(r'doge_hist.csv')

#Getting 90 days worth of hourly data
bit_hist_hr=cg.get_coin_market_chart_range_by_id(id='bitcoin', vs_currency='usd',include_market_cap='true', include_24hr_vol='true', include_24hr_change='true',from_timestamp=1636520400,to_timestamp=1639058407)
eth_hist_hr=cg.get_coin_market_chart_range_by_id(id='ethereum', vs_currency='usd',include_market_cap='true', include_24hr_vol='true', include_24hr_change='true',from_timestamp=1636520400,to_timestamp=1639058407)
doge_hist_hr=cg.get_coin_market_chart_range_by_id(id='dogecoin', vs_currency='usd',include_market_cap='true', include_24hr_vol='true', include_24hr_change='true',from_timestamp=1636520400,to_timestamp=1639058407)
shib_hist_hr=cg.get_coin_market_chart_range_by_id(id='shiba-inu', vs_currency='usd',include_market_cap='true', include_24hr_vol='true', include_24hr_change='true',from_timestamp=1636520400,to_timestamp=1639058407)

df_bit_hist_hr = pd.DataFrame(bit_hist_hr)
df_eth_hist_hr = pd.DataFrame(eth_hist_hr)
df_shib_hist_hr = pd.DataFrame(shib_hist_hr)
df_doge_hist_hr = pd.DataFrame(doge_hist_hr)

df_bit_hist_hr.to_csv(r'bit_hist_hr.csv')
df_eth_hist_hr.to_csv(r'eth_hist_hr.csv')
df_shib_hist_hr.to_csv(r'shib_hist_hr.csv')
df_doge_hist_hr.to_csv(r'doge_hist_hr.csv')

#1636520400
#1604203200

# 2020  11/01/2020 - 01/22/21 Getting 90 days worth of hourly data
st_bit_hist_hr=cg.get_coin_market_chart_range_by_id(id='bitcoin', vs_currency='usd',include_market_cap='true', include_24hr_vol='true', include_24hr_change='true',from_timestamp=1604203200,to_timestamp=1611550800)
st_eth_hist_hr=cg.get_coin_market_chart_range_by_id(id='ethereum', vs_currency='usd',include_market_cap='true', include_24hr_vol='true', include_24hr_change='true',from_timestamp=1604203200,to_timestamp=1611550800)
st_doge_hist_hr=cg.get_coin_market_chart_range_by_id(id='dogecoin', vs_currency='usd',include_market_cap='true', include_24hr_vol='true', include_24hr_change='true',from_timestamp=1604203200,to_timestamp=1611550800)
st_shib_hist_hr=cg.get_coin_market_chart_range_by_id(id='shiba-inu', vs_currency='usd',include_market_cap='true', include_24hr_vol='true', include_24hr_change='true',from_timestamp=1604203200,to_timestamp=1611550800)

st_df_bit_hist_hr = pd.DataFrame(st_bit_hist_hr)
st_df_eth_hist_hr = pd.DataFrame(st_eth_hist_hr)
st_df_shib_hist_hr = pd.DataFrame(st_shib_hist_hr)
st_df_doge_hist_hr = pd.DataFrame(st_doge_hist_hr)

st_df_bit_hist_hr.to_csv(r'20_bit_hist_hr.csv')
st_df_eth_hist_hr.to_csv(r'20_eth_hist_hr.csv')
st_df_shib_hist_hr.to_csv(r'20_shib_hist_hr.csv')
st_df_doge_hist_hr.to_csv(r'20_doge_hist_hr.csv')


'''
#attempt to store into db
et_df = pd.DataFrame(ethereum, columns = ['Ethereum Value'])
et_df.index.name = 'Every Hour Count in the Past 30 Days'
et_df.to_csv(r'Ethereum.csv')
df = pd.read_csv("Ethereum.csv")

factory = griddb.StoreFactory.get_instance()
argv = sys.argv
try:
#Get GridStore object
    gridstore = factory.get_store(
        notification_member="griddb-server:10001",
        cluster_name="defaultCluster",
        username="admin",
        password="admin"
    )

'''


