################################################

# IST687, Standard Homework Heading

# 

# Student name: Paul Phillips

# Homework number: Final Project

# Date due: 1/17/2021

#

# Attribution statement: (choose only one)
# 2. I did this homework with help from the book and the professor and these Internet sources:
# Project Context Sources:
# https://www.investopedia.com/terms/t/termdeposit.asp
# https://www.westpac.com.au/personal-banking/bank-accounts/term-deposit/savings-vs-term-deposit/#:~:text=What%20is%20a%20term%20deposit,on%20your%20money%20will%20be.
# http://archive.ics.uci.edu/ml/datasets/Bank+Marketing
# https://en.wikipedia.org/wiki/Education_in_Portugal
# https://www.quora.com/What-is-meant-by-employment-variation-rate-Does-it-affect-in-any-way-the-financial-decisions-that-an-individual-takes

# Season Conversion Source:
# https://deepgreenpermaculture.com/2017/03/02/converting-months-to-seasons-northern-and-southern-hemisphere-meteorological-and-astronomical/

# R Code Sources:
# https://stackoverflow.com/questions/1169248/test-if-a-vector-contains-a-given-element
# https://cran.r-project.org/web/packages/dtt/dtt.pdf
# https://rstudio-pubs-static.s3.amazonaws.com/110183_06adc5f01fc940f98fdc0822ac408de0.html
# https://datatricks.co.uk/one-hot-encoding-in-r-three-simple-methods
# https://www.datanovia.com/en/lessons/k-means-clustering-in-r-algorith-and-practical-examples/
# https://www.datanovia.com/en/lessons/determining-the-optimal-number-of-clusters-3-must-know-methods/
# https://machinelearningmastery.com/feature-selection-with-the-caret-r-package/
# https://machinelearningmastery.com/learning-vector-quantization-for-machine-learning/
# https://bradleyboehmke.github.io/HOML/random-forest.html
# https://datascience.stackexchange.com/questions/12697/feature-importance-how-to-choose-the-number-of-best-features
# https://dataaspirant.com/feature-selection-techniques-r/
# https://rpubs.com/aaronsc32/quadratic-discriminant-analysis

# Run these three functions to get a clean test of homework code

dev.off() # Clear the graph window

cat('\014')  # Clear the console

rm(list=ls()) # Clear user objects from the environment


# Set working directory 

setwd("C:\\Users\\User\\Desktop\\SYRACUSE\\IST687\\ProjectIdeas\\bankMarketingCampaign\\") # Change to the folder containing your homework data files

# Your homework specific code goes below here
# libraries
library(tidyverse)
library(jsonlite)
library(RCurl)
library(viridis)
library(wesanderson)
library(RColorBrewer)
library(ggplot2)
library(maps)
library(ggmap)
library(mapproj)
library(arules)
library(arulesViz)
library(caret)
library(kernlab)
library(MASS)
library(e1071)
library(varImp)
library(dtt)
library(factoextra)
library(NbClust)
library(mlbench)
library(randomForest)
library(class)

################################################################################

################################################################################
#### Import data
bankSurvey <- data.frame(read.csv('bank-additional-full.csv',
                                  sep=';',
                                  stringsAsFactors = FALSE))

## Inspect data
head(bankSurvey)
glimpse(bankSurvey)

#### Handle missing data
# Note: There are several forms of missing values that need to be addressed:
# Note: Keep 'poutcome' for now, need to be able to represent new clients. Keep note
#       for analytics phase though.

# 'pdays' == 999 means client was not previously contacted
bankSurvey[bankSurvey$pdays == 999, 'pdays'] = NA

# Inspect amount of missingness
print(paste('Proportion of missingness in pdays: ', toString(sum(is.na(bankSurvey$pdays))/nrow(bankSurvey))))
print(paste('Unique values in pdays: ', toString(unique(bankSurvey$pdays))))

# 'poutcome' == 'nonexistent' converts directly to missing data
#bankSurvey[bankSurvey$poutcome == 'nonexistent', 'poutcome'] = NA

# Inspect amount of missingness
#print(paste('Proportion of missingness in pdays: ', toString(sum(is.na(bankSurvey$poutcome))/nrow(bankSurvey))))
#print(paste('Unique values in pdays: ', toString(unique(bankSurvey$poutcome))))

#-------------------------------------------------------------------------------
# Response: It would appear even without converting '999' to NA it appears this
#           value is present in 96% of the rows so it does not offer anything
#           useful for 'pdays'. Additionally, 'poutcome' has 86% of its elements
#           represented by the value 'nonexistent'. This means there is going to
#           be an under representation of 'success' or 'failure' levels. Will keep
#           for now but this could cause issues in later analysis. 
bankSurvey <- subset(bankSurvey, select=-c(pdays))
#-------------------------------------------------------------------------------

# Inspect column unique values
# Grab all columns with unique values <10 and store in an array
# Note: only purpose of this object is to swiftly gain insights on the categorical
#       columns in data set. 

catColumns = {}

# Iterate through column dimension of data set
for (j in 1:dim(bankSurvey)[2]) {
  # Extract unique values of jth column
  uniqueValue <- unique(bankSurvey[,j])
  # If the amount of unique values are greater than 10, skip onto the next iteration
  if (length(uniqueValue) > 10) {
    next
  } else {
    # dynamically assign given column name as array key and save unique values of column as values.
    catColumns[colnames(bankSurvey)[j]] <- list(uniqueValue)
  }
    
}

# Inspect Array
catColumns

# Note: lots of columns contains values 'unkown'. Let's explore proportions
print(paste('Proportion of unknown in marital:',toString(nrow(bankSurvey[bankSurvey$marital=='unknown',])/nrow(bankSurvey))))
print(paste('Proportion of unknown in education:',toString(nrow(bankSurvey[bankSurvey$education=='unknown',])/nrow(bankSurvey))))
print(paste('Proportion of unknown in default:',toString(nrow(bankSurvey[bankSurvey$default=='unknown',])/nrow(bankSurvey))))
print(paste('Proportion of unknown in housing:',toString(nrow(bankSurvey[bankSurvey$housing=='unknown',])/nrow(bankSurvey))))
print(paste('Proportion of unknown in loan:',toString(nrow(bankSurvey[bankSurvey$loan=='unknown',])/nrow(bankSurvey))))

#-------------------------------------------------------------------------------
# Response: It seems all but the 'default' column contain <4% of this categorical
#           value, so for computational reasons I am going to drop these rows so
#           I can convert those attributes to type 'bool'. I will track how much
#           of the data set is lost to ensure it was minimal.

OG_rowCount <- nrow(bankSurvey)

bankSurvey <- bankSurvey[(bankSurvey$marital!='unknown') &
                                       (bankSurvey$education!='unknown') &
                                       (bankSurvey$housing!='unknown') &
                                       (bankSurvey$loan!='unknown'),]

# Looks like 7% of the data was lost
print(paste('Proportion of data lost:', toString(1-(nrow(bankSurvey)/OG_rowCount))))

# Convert housing and loan to unknown
# Note: 'contact' is also only two levels so for computational efficiency that'll
#       get converted to 'bool' as well. 
bankSurvey$housing <- as.factor(bankSurvey$housing == 'yes')
bankSurvey$loan <- as.factor(bankSurvey$loan == 'yes')
bankSurvey$cellContact <- as.factor(bankSurvey$contact == 'cellular')

# Drop contact
bankSurvey <- subset(bankSurvey, select=-c(contact))
#-------------------------------------------------------------------------------

#### Condensing categorical levels in data set
# Note: 'High school refers to k-12 in Portugal and basic.#y refers to number of
#       years spent in school (did not complete highschool). Let's condense everything
#       under high school as its own categories
bankSurvey$condEducation <- rep('lower_education', nrow(bankSurvey))
bankSurvey[(bankSurvey$education=="high.school"),'condEducation'] <- 'high_school'
bankSurvey[(bankSurvey$education=="professional.course"),'condEducation'] <- 'professional_course'
bankSurvey[(bankSurvey$education=="university.degree"),'condEducation'] <- 'university_degree'

bankSurvey$condEducation <- as.factor(bankSurvey$condEducation)

# Inspect condensed education column
# The new levels seem fairly proportionate.
summary(factor(bankSurvey$condEducation))

# Drop OG education column
bankSurvey <- subset(bankSurvey, select=-c(education))
# Visualize new levels with barchart
bankSurvey %>% 
  group_by(condEducation) %>% 
  summarise(edCounts=n()) %>% 
  ggplot() + 
  aes(x=condEducation,
      y=edCounts) +
  geom_col() +
  ggtitle('Barchart of Condensed Education Levels')

## Inspect and condense month
bankSurvey %>% 
  ggplot() +
  aes(x=month) +
  geom_histogram(stat='count') +
  ggtitle('Barchart of Month')

# As expected the distribution of this column is quite skewed. These values will
# be converted to 4 standard seasons
# Astronomical Conversion for Northern Hemisphere will be used since Portugal falls
# within the Northern Hemisphere (see links above for source)
bankSurvey$season <- rep('winter', nrow(bankSurvey))
# Spring
bankSurvey[(bankSurvey$month=="apr") |
             (bankSurvey$month=="may") |
             (bankSurvey$month=="jun"),'season'] <- 'spring'
# Summer
bankSurvey[(bankSurvey$month=="jul") |
             (bankSurvey$month=="aug") |
             (bankSurvey$month=="sep"),'season'] <- 'summer'
# Autumn
bankSurvey[(bankSurvey$month=="oct") |
             (bankSurvey$month=="nov") |
             (bankSurvey$month=="dec"),'season'] <- 'autumn'

# Convert to factor
bankSurvey$season <- as.factor(bankSurvey$season)

## Inspect new season column
# Note: Still not great, but is at least a simpler column. The data set predominantly
#       takes place in the spring and summer.
bankSurvey %>% 
  ggplot() +
  aes(x=season) +
  geom_histogram(stat='count') +
  ggtitle('Barchart of Season')

# Drop OG education column
bankSurvey <- subset(bankSurvey, select=-c(month))

## Inspect distribution of days_of_week
# These are very evenly distributed, no modification needed
bankSurvey %>% 
  ggplot() +
  aes(x=day_of_week) +
  geom_histogram(stat='count') +
  ggtitle('Barchart of Week Days')

## Inspect distribution of 'previous'
# Note: 'previous' signifies # of contacts performed before this campaign for this
#       client
bankSurvey %>% 
  ggplot() +
  aes(x=previous) +
  geom_histogram() +
  ggtitle('Histogram of Number of Previous Contacts')

# Note: This column is heavily skewed to '0', so this will be converted to 'bool'
#       'previousContact' instead (I did go back and check the impact of the rows
#       that I took out and it did not change these proportions).
bankSurvey$previousContact <- as.factor(bankSurvey$previous == 0)

# Drop OG column
bankSurvey <- subset(bankSurvey, select=-c(previous))

## Inspect 'poutcome'
# Note: Recall ~86% of this column is 'nonexistent'; that said will keep for now
bankSurvey %>% 
  ggplot() +
  aes(x=poutcome) +
  geom_histogram(stat = 'count') +
  ggtitle('Barchart of Previous Contact Outcome')

## Inspect 'emp.var.rate' (employment variation rate)
# Note: Could very well be referring to 'cyclical employment variation'.
# Note: Since this is a cyclical pattern, let's perform a sine transformation on such.
# Note: For now, leave as is; might revisit converting all of the economic parameters later
bankSurvey %>% 
  ggplot() +
  aes(x=emp.var.rate) +
  geom_histogram() +
  ggtitle('Histogram of Employment Variation Rate')

## Perform univariate discrete sine on 'emp.var.rate'
#test <- dtt(bankSurvey$emp.var.rate,
#            type='dst')

#plot(test)

## Inspect 'campaign'; number of calls performed during campaign
# Note: Heavily skewed towards <10 (exponentially distributed)
bankSurvey %>% 
  ggplot() +
  aes(x=campaign) +
  geom_histogram(stat = 'count') +
  ggtitle('Histogram of Number of Campaign Contacts')

## Inspect relationship between 'output' and 'campaign' (same with emp.var.rate)
# Counter skewedness with log() transformation on 'campaign'
# Note: medians for these two subgroups are almost equal
bankSurvey %>% 
  ggplot() +
  aes(x=y,
      y=log(campaign)) +
  geom_boxplot() +
  ggtitle('Number of Campaign Contacts vs. Subscription Status')

# Take subset of bank survey data (campaign < 10) to cross validate findings
subBankSurvey <- bankSurvey[bankSurvey$campaign <= 10,]

# Note: This too confirms log() transformation results; medians are almost exactly
#       the same which can be interpreted as the number of campaign calls not being 
#       a great contributor to the response. This can be confirmed later in the
#       modeling phase.
subBankSurvey %>% 
  ggplot() +
  aes(x=y,
      y=campaign) +
  geom_boxplot() +
  ggtitle('Subset: Number of Campaign Contacts vs. Subscription Status')

## Inspect 'job'
## Note: Many levels with uncertainty on how to condense: will directly convert to
#        type 'factor' 
bankSurvey %>% 
  ggplot() +
  aes(x=job) +
  geom_histogram(stat = 'count') +
  ggtitle('Histogram of Number of Campaign Contacts') +
  theme(axis.text.x = 
          element_text(angle = 45, hjust=1))

bankSurvey$job <- as.factor(bankSurvey$job)

## Inpsect distribution of output
# Note: The majority of responses are 'no'; very few 'yes' responses
bankSurvey %>% 
  ggplot() +
  aes(x=y) +
  geom_histogram(stat = 'count') +
  ggtitle('Barchart of Response Variable')

# Convert response to boolean
bankSurvey$respondedYes <- as.factor(bankSurvey$y == 'yes')

# Drop OG column
bankSurvey <- subset(bankSurvey,
                     select=-c(y))
  
## Convert categorical columns to dummy
# Note: This will help improve computational efficiency in the modeling phase
# Note: The OG data frame will be kept as for associative ruling later

dummy <- dummyVars(" ~ .",data = subset(bankSurvey,
                                        select=c(marital,
                                                 default,
                                                 day_of_week,
                                                 poutcome,
                                                 condEducation,
                                                 season)))

bankSurvey_dummy <- data.frame(predict(dummy, newdata=subset(bankSurvey,
                                                             select=c(marital,
                                                                      default,
                                                                      day_of_week,
                                                                      poutcome,
                                                                      condEducation,
                                                                      season))))

# Drop OG categorical columns
# Note: Here we are specifying that the columns not converted to dummy will be joined
#       at the end of bankSurvey_dummy
bankSurvey_dummy[,dim(bankSurvey_dummy)[2]+1:dim(subset(bankSurvey,
                                                        select=-c(marital,
                                                                  default,
                                                                  day_of_week,
                                                                  poutcome,
                                                                  condEducation,
                                                                  season)))[2]] <- subset(bankSurvey,
                                                                                          select=-c(marital,
                                                                                                    default,
                                                                                                    day_of_week,
                                                                                                    poutcome,
                                                                                                    condEducation,
                                                                                                    season))

# Inspect stucture of new data set:
# There are now 36 columns in this dataframe
glimpse(bankSurvey_dummy)
dim(bankSurvey_dummy)

## Check for correlation among numeric features

# Note: Correlation between columns seems very low; but there does seem to be a
#       presence of clusters between these two variables
# Note: Not really a relationship present between response and these inputs

# cons.price.idx vs cons.conf.idx
bankSurvey %>% 
  ggplot() +
  aes(x=cons.price.idx,
      y=cons.conf.idx,
      color=respondedYes) +
  geom_point(alpha=0.1) +
  geom_jitter(width = 0.1,
              height = 0.15) +
  ggtitle('Scatter Plot of Cons.Price.Index vs Cons.Conf.Index')

# cons.price.idx vs euribor3m
# Note: Responses are scattered amongst all clusters present
bankSurvey %>% 
  ggplot() +
  aes(x=cons.price.idx,
      y=euribor3m,
      color=respondedYes) +
  geom_point() +
  geom_jitter(width = 0.1,
              height = 0.1) +
  ggtitle('Scatter Plot of Cons.Price.Index vs euribor3m')

# cons.price.idx vs nr.employed
# Note: Responses are scattered amongst all clusters present
bankSurvey %>% 
  ggplot() +
  aes(x=cons.price.idx,
      y=nr.employed,
      color=respondedYes) +
  geom_point(alpha=0.1) +
  geom_jitter(width = 0.1,
              height = 5) +
  ggtitle('Scatter Plot of Cons.Price.Index vs nr.employed')


# cons.conf.idx vs nr.employed
# Note: Responses are scattered amongst all clusters present
bankSurvey %>% 
  ggplot() +
  aes(x=cons.conf.idx,
      y=euribor3m,
      color=respondedYes) +
  geom_point() +
  geom_jitter(width = 0.1,
              height = 0.1) +
  ggtitle('Scatter Plot of cons.conf.idx vs euribor3m')

# cons.conf.idx vs nr.employed
# Note: Responses are scattered amongst all clusters present
bankSurvey %>% 
  ggplot() +
  aes(x=cons.conf.idx,
      y=nr.employed,
      color=respondedYes) +
  geom_point() +
  geom_jitter(width = 0.2,
              height = 5) +
  ggtitle('Scatter Plot of cons.conf.idx vs nr.employed')

# euribor3m vs nr.employed
# Note: Responses are scattered amongst all clusters present
bankSurvey %>% 
  ggplot() +
  aes(x=euribor3m,
      y=nr.employed,
      color=respondedYes) +
  geom_point() +
  geom_jitter(width = 0.1,
              height = 5) +
  ggtitle('Scatter Plot of euribor3m vs nr.employed')


bankSurvey %>% 
  ggplot() +
  aes(x=euribor3m,
      y=nr.employed,
      fill=respondedYes) +
  geom_col() +
  ggtitle('Scatter Plot of euribor3m vs nr.employed')

#-------------------------------------------------------------------------------
# Response: As is the economic metrics do not seem to show any clear trends with
#           respect to the response variable. Although there are no signs of linear
#           relationships present between the economic metrics, there are indeed
#           present clusters. The next task will be to perform kmeans clustering
#           and see if there is indeed a strong presence of non-linear relationships
#           between the economic input variables. 
#-------------------------------------------------------------------------------
## Explore potential clusters among economic metrics
# Note: Apply kmeans clustering to find clusters
set.seed(111)

# Centers=5, iter.max=30, nstart=25
ecMetricClusters <- kmeans(subset(bankSurvey_dummy,
                                  select=c(emp.var.rate,
                                           cons.price.idx,
                                           euribor3m,
                                           nr.employed)),
                           centers = 5,
                           iter.max = 30,
                           nstart = 25)

# Visualize results
fviz_cluster(ecMetricClusters,subset(bankSurvey_dummy,
                                     select=c(emp.var.rate,
                                     cons.price.idx,
                                     euribor3m,
                                     nr.employed))) +
ggtitle('Economic Metric Clustering Results: K=5')


#set.seed(111)

# Centers=10, iter.max=30, nstart=25
#ecMetricClusters <- kmeans(subset(bankSurvey_dummy,
#                                  select=c(emp.var.rate,
#                                           cons.price.idx,
#                                           euribor3m,
#                                           nr.employed)),
#                           centers = 10,
#                           iter.max = 30,
#                           nstart = 25)

# Visualize results
#fviz_cluster(ecMetricClusters,subset(bankSurvey_dummy,
#                                     select=c(emp.var.rate,
#                                              cons.price.idx,
#                                              euribor3m,
#                                              nr.employed))) +
#  ggtitle('Economic Metric Clustering Results: K=10')

#-------------------------------------------------------------------------------
#Within cluster sum of squares by cluster:
#  [1] 670159.82  63229.19  40948.44 248329.11   2321.24
#   (between_SS / total_SS =  99.5 %)


# Response: As seen above the 5-means clustering outputs close to perfect results
#           as the betweenness sum of squares divided by total sum of squares is
#           almost 1. This means the 'betweenness' of the clusters explains almost
#           the entirety of the present deviance. We will confirm results with
#           further optimization using the following methods.
#-------------------------------------------------------------------------------

## Can't seem to successfully run operation with current computer configuration
## Optimization Approach
# Note: The following methods determine the optimal number of clusters 'k' to use
#       for kmeans clustering
# Elbow method
#fviz_nbclust(subset(bankSurvey_dummy,
#                    select=c(emp.var.rate,
#                             cons.price.idx,
#                             euribor3m,
#                             nr.employed)), 
#             kmeans,
#             method = "wss") +
 # geom_vline(xintercept = 4, linetype = 2)+
#  ggtitle("Ecomomic Clusters: Elbow method")

# Silhouette method
# Note: recommends k=8
set.seed(111)
fviz_nbclust(subset(bankSurvey_dummy,
                    select=c(emp.var.rate,
                             cons.price.idx,
                             euribor3m,
                             nr.employed)), 
             kmeans,
             method = "silhouette")+
  ggtitle("Ecomomic Clusters: Silhouette method")

## Can't seem to successfully run operation with current computer configuration
# Gap statistic
# Uss
#set.seed(111)
#fviz_nbclust(subset(bankSurvey_dummy,
#                    select=c(emp.var.rate,
#                             cons.price.idx,
#                             euribor3m,
#                             nr.employed)), 
#             kmeans, 
#             nstart = 25,  
#             method = "gap_stat")+
#  ggtitle("Ecomomic Clusters: Gap method")

## Run kmeans=8
set.seed(111)

# Centers=8, iter.max=30, nstart=25
ecMetric8Clusters <- kmeans(subset(bankSurvey_dummy,
                                  select=c(emp.var.rate,
                                           cons.price.idx,
                                           euribor3m,
                                           nr.employed)),
                           centers = 8,
                           iter.max = 30,
                           nstart = 25)

# Operation times out
# Visualize results
fviz_cluster(ecMetric8Clusters,subset(bankSurvey_dummy,
                                     select=c(emp.var.rate,
                                              cons.price.idx,
                                              euribor3m,
                                              nr.employed))) +
  ggtitle('Economic Metric Clustering Results: K=8')

#-------------------------------------------------------------------------------
# Within cluster sum of squares by cluster:
#   [1]    29.192246   250.363547     8.808385  4777.608825  2321.240030   116.170674 63229.189353    35.718201
#     (between_SS / total_SS = 100.0 %)

# Response: The silhouette approach to kmeans optimization in this problem suggests
#           the use of 8 clusters. Since 5-means producing directly similar results
#           in the optimization output, I will stick with 5-means results as it 
#           better balances the bias/variance tradeoff. Although it doesn't account
#           for all the deviance present, there is less risk of the model overfitting
#           the data. 

# Create new column in data frame
bankSurvey_dummy$ecMetricClusters <- as.factor(ecMetricClusters$cluster)

# Compare results in barchart
bankSurvey_dummy %>% 
  ggplot() +
  aes(x=ecMetricClusters,
      fill=respondedYes) +
  geom_histogram(stat = 'count') +
  xlab('5-Means Clusters: Economic Metrics') +
  ylab('Row Counts') +
  ggtitle('Barchart: Target Variable vs. Econ Metric Clusters')

# Note: Proportions of yes/no responses seem to be almost even for clusters '3'
#       and '4'.
#-------------------------------------------------------------------------------

################################################################################

################################################################################
#### Determine top inputs for response
# Here Learning Vector Quantization (LVG) is used to determine variable importance
# Note: LVG is a neural network that allows the user to choose how many training
#       instances to hang onto 

## Note: Again didn't have time to determine computer configuration for this procedure
# Stage variable import data
#control <- trainControl(method='repeatedcv',
#                        number=10, # number of codebook vectors
#                        repeats = 3) # 3 training instances

#set.seed(111)

# Train model to determine input importance
# Note: response needs to be stored as factor
#modelVarImportance <- train(as.factor(respondedYes) ~., 
#                            data = bankSurvey_dummy,
#                            method='lvq',
#                            preProcess="scale", 
#                            trControl=control)

#### Random Forest for Feature Selection
# Note: Rule of thumb for # of features to consider for classification is sqrt(p)
set.seed(111)

# Note: randomForest knows to apply rule of thumb so long as the response is stored
#       as a factor
fit_rf <- randomForest(respondedYes ~ .,
                       data=bankSurvey_dummy)

# Estimate variable importance
# Order results (decreasing)
orderImportance <- order(importance(fit_rf),
                         decreasing = TRUE)

# Display sorted gini indices
print(data.frame(importance(fit_rf)[orderImportance,]))

# Visualize results (supported by base visualizations)
# Note: Number of features to retain can be retained a few different ways; since
#       there isn't necessarily a specified number required to use, we will follow
#       the 'biggest cutoff' rule of thumb; that is, retain all variables up to
#       the biggest 'drop' (differnce) in importance scores.

#-------------------------------------------------------------------------------
#> print(data.frame(importance(fit_rf)[orderImportance,]))
#importance.fit_rf..orderImportance...
#duration                                                  2.187454e+03
#euribor3m                                                 6.969558e+02
#age                                                       5.392481e+02
#job                                                       4.594185e+02
#nr.employed                                               4.023955e+02
#campaign                                                  2.618005e+02
#ecMetricClusters                                          2.091870e+02
#poutcomesuccess                                           1.984022e+02
#cons.conf.idx                                             1.922562e+02
#cons.price.idx                                            1.844242e+02
#emp.var.rate                                              1.395430e+02
#housing                                                   1.089895e+02
#condEducationuniversity_degree                            8.178485e+01
#loan                                                      7.863668e+01
#maritalmarried                                            7.846528e+01
#day_of_weekthu                                            7.667213e+01
#day_of_weekmon                                            7.560116e+01
#condEducationhigh_school                                  7.410286e+01
#maritalsingle                                             7.287875e+01
#day_of_weektue                                            7.282951e+01
#day_of_weekwed                                            7.271639e+01
#cellContact                                               7.222905e+01
#poutcomefailure                                           7.006409e+01
#day_of_weekfri                                            6.965532e+01
#condEducationlower_education                              6.803471e+01
#condEducationprofessional_course                          6.024096e+01
#maritaldivorced                                           5.032196e+01
#previousContact                                           4.989482e+01
#poutcomenonexistent                                       4.904156e+01
#defaultunknown                                            3.891883e+01
#defaultno                                                 3.791182e+01
#seasonspring                                              3.245817e+01
#seasonwinter                                              3.096865e+01
#seasonsummer                                              2.231723e+01
#seasonautumn                                              1.707268e+01
#defaultyes                                                9.876578e-05

# Response: Based on the results above, I will take on everything down to 'housing',
#           where the e+02 size indices stop.
#-------------------------------------------------------------------------------


################################################################################
#### Modeling

# Partition data
set.seed(111)

# Randomly sample elements to go into a training data set
trainList <- createDataPartition(y=bankSurvey_dummy$respondedYes, p=0.8, list=FALSE)

# Build train, test
# When not possible, train on entire set and either use k-Fold CV on training data
# with model, or perform bootstrap on prediction parameters to determine model 
# performance.
trainSet <- bankSurvey_dummy[trainList,]
testSet <- bankSurvey_dummy[-trainList,]

# Subset to only include selected columns
trainSet <- subset(trainSet,
                   select=c(duration,
                            euribor3m,
                            age,
                            job,
                            nr.employed,
                            campaign,
                            ecMetricClusters,
                            cons.conf.idx,
                            poutcomesuccess,
                            cons.price.idx,
                            emp.var.rate,
                            housing,
                            respondedYes))

testSet <- subset(testSet,
                  select=c(duration,
                           euribor3m,
                           age,
                           job,
                           nr.employed,
                           campaign,
                           ecMetricClusters,
                           cons.conf.idx,
                           poutcomesuccess,
                           cons.price.idx,
                           emp.var.rate,
                           housing,
                           respondedYes))

### Random Forest (refined)
# Note: Rule of thumb for # of features to consider for classification is sqrt(p)
set.seed(111)

# Note: randomForest knows to apply rule of thumb so long as the response is stored
#       as a factor
rfTrain <- randomForest(respondedYes ~ .,
                       data=trainSet)

# Make predictions with random forest model
rfPredOut <- predict(rfTrain,newdata=testSet)

# Create a confusion matrix
rfConfMatrix <- table(rfPredOut, testSet$respondedYes)

# Proportions
# Model's 'TRUE' predictions were only half right
#rfPredOut      FALSE       TRUE
#   FALSE 0.85625081 0.05554833
#   TRUE  0.03252244 0.05567842

# Correctly predicted output for TRUE: 0.05567842/(0.05567842+0.05554833)
# Calculation: 0.5005848
prop.table(rfConfMatrix)

# Accuracy Rate
# [1] 0.9119292
sum(diag(rfConfMatrix))/sum(rfConfMatrix)

### Quadratic Discriminant Analysis
# Note: Here we will just use the default values for the algorithm
set.seed(111)

# train model
qdaTrain <- qda(respondedYes ~ .,
                data = trainSet)


# Make predictions with quadratic discriminant analysis
qdaPredOut <- predict(qdaTrain,newdata=testSet)$class

# Create a confusion matrix
qdaConfMatrix <- table(qdaPredOut, testSet$respondedYes)

# Proportions
# Model's 'TRUE' predictions more right than wrong (better than flipping a coin)
#qdaPredOut      FALSE       TRUE
#   FALSE 0.80473527 0.04410043
#   TRUE  0.08403799 0.06712632
# Correctly predicted output for TRUE: 0.06712632/(0.06712632+0.04410043)
# Calculation: 0.6035088
prop.table(qdaConfMatrix)

# Accuracy Rate
# [1] 0.8718616
sum(diag(qdaConfMatrix))/sum(qdaConfMatrix)


### SVM
# Reconfigure training ratio
# Partition data
set.seed(111)

# Randomly sample elements to go into a training data set
trainList <- createDataPartition(y=bankSurvey_dummy$respondedYes, p=0.45, list=FALSE)

# Build train, test
# When not possible, train on entire set and either use k-Fold CV on training data
# with model, or perform bootstrap on prediction parameters to determine model 
# performance.
trainSet <- bankSurvey_dummy[trainList,]
testSet <- bankSurvey_dummy[-trainList,]

# Subset to only include selected columns
trainSet <- subset(trainSet,
                   select=c(duration,
                            euribor3m,
                            age,
                            job,
                            nr.employed,
                            campaign,
                            ecMetricClusters,
                            cons.conf.idx,
                            poutcomesuccess,
                            cons.price.idx,
                            emp.var.rate,
                            housing,
                            respondedYes))

testSet <- subset(testSet,
                  select=c(duration,
                           euribor3m,
                           age,
                           job,
                           nr.employed,
                           campaign,
                           ecMetricClusters,
                           cons.conf.idx,
                           poutcomesuccess,
                           cons.price.idx,
                           emp.var.rate,
                           housing,
                           respondedYes))


# Train model
svmFit <- train(respondedYes ~ ., 
             data=trainSet,
             method='svmRadial', # Particular type of svm algo
             preProc=c("center","scale"))


# Make predictions with support vector machines
svmPredOut <- predict(svmFit,newdata=testSet)

# Create a confusion matrix
svmConfMatrix <- table(svmPredOut, testSet$respondedYes)

# Proportions
# Model's 'TRUE' predictions were more incorrect than they were correct
#svmPredOut      FALSE       TRUE
#   FALSE 0.87445601 0.07762535
#   TRUE  0.01428571 0.03363292
# Correctly predicted output for TRUE: 0.03363292/(0.03363292+0.07762535)
# Calculation: 0.3022959
prop.table(svmConfMatrix)

# Accuracy Rate
# [1] 0.9080889
sum(diag(svmConfMatrix))/sum(svmConfMatrix)

#-------------------------------------------------------------------------------
# Response: In conclusion to the modeling methods used, I would determine QDA
#           (Quadratic Discriminant Analysis) to have to best results. Although 
#           the model had the worst overall accuracy rating it successfully
#           classified ~60% of all individuals who would subscribe to a term deposit.
#           Random Forest predicted subscribers just a feather weight heavier than
#           a coin flip and SVM predicted subscribers worst than a coin flip.
#           The models are having a hard time predicting for subscribers because
#           there are so few people who actually agree in the dataset. This
#           was somewhat accounted for with partitioning methods used, but further
#           techniques may be required in order to improve performance. 
#           
#-------------------------------------------------------------------------------

################################################################################

#### A Ruling

# Convert data frame to be all factor columns (for easy filtering of frequently 
# occurring items in baskets)
bankSurveyRules <- data.frame(lapply(bankSurvey, as.factor))

# Covert bankSurveyRules to type 'transaction'
bankSurveyTransactions <- as(bankSurveyRules, 'transactions')

# Visualize item frequency plot
# Looks like default=no, loan=FALSE, poutcome=nonexistent, and previousContact=TRUE
# are the most frequently occuring items across available basekts
itemFrequencyPlot(bankSurveyTransactions, support=0.15)

# Combination gives exactly 16 rules
subscriberRules <- apriori(bankSurveyTransactions,
                          parameter = list(support=0.005, confidence=0.70),
                          appearance = list(default='lhs', 
                                            rhs=c('respondedYes=TRUE')))
# Show top 10 rules
# Note: Results offer better insight with 'Likelihood.to.recommend' removed since
#       our RHS category was derived from such!
inspect(subscriberRules)

# Plot top 10 rules
plot(subscriberRules,
     cex=1.5)

# Results
#> inspect(subscriberRules)
#     lhs                                                                                              rhs                 support     confidence coverage    lift     count
#[1]  {poutcome=success,season=summer}                                                              => {respondedYes=TRUE} 0.007830996 0.7115839  0.011005021 6.394938 301  
#[2]  {poutcome=success,season=summer,previousContact=FALSE}                                        => {respondedYes=TRUE} 0.007830996 0.7115839  0.011005021 6.394938 301  
#[3]  {poutcome=success,cellContact=TRUE,season=summer}                                             => {respondedYes=TRUE} 0.007310664 0.7150127  0.010224523 6.425753 281  
#[4]  {default=no,poutcome=success,season=summer}                                                   => {respondedYes=TRUE} 0.007752946 0.7146283  0.010848922 6.422298 298  
#[5]  {loan=FALSE,poutcome=success,season=summer}                                                   => {respondedYes=TRUE} 0.006790332 0.7190083  0.009444025 6.461660 261  
#[6]  {poutcome=success,cellContact=TRUE,season=summer,previousContact=FALSE}                       => {respondedYes=TRUE} 0.007310664 0.7150127  0.010224523 6.425753 281  
#[7]  {default=no,poutcome=success,season=summer,previousContact=FALSE}                             => {respondedYes=TRUE} 0.007752946 0.7146283  0.010848922 6.422298 298  
#[8]  {loan=FALSE,poutcome=success,season=summer,previousContact=FALSE}                             => {respondedYes=TRUE} 0.006790332 0.7190083  0.009444025 6.461660 261  
#[9]  {default=no,poutcome=success,cellContact=TRUE,season=summer}                                  => {respondedYes=TRUE} 0.007232614 0.7183463  0.010068424 6.455711 278  
#[10] {loan=FALSE,poutcome=success,cellContact=TRUE,season=summer}                                  => {respondedYes=TRUE} 0.006374067 0.7227139  0.008819627 6.494962 245  
#[11] {default=no,loan=FALSE,poutcome=success,season=summer}                                        => {respondedYes=TRUE} 0.006738299 0.7234637  0.009313942 6.501701 259  
#[12] {default=no,poutcome=success,cellContact=TRUE,season=summer,previousContact=FALSE}            => {respondedYes=TRUE} 0.007232614 0.7183463  0.010068424 6.455711 278  
#[13] {loan=FALSE,poutcome=success,cellContact=TRUE,season=summer,previousContact=FALSE}            => {respondedYes=TRUE} 0.006374067 0.7227139  0.008819627 6.494962 245  
#[14] {default=no,loan=FALSE,poutcome=success,season=summer,previousContact=FALSE}                  => {respondedYes=TRUE} 0.006738299 0.7234637  0.009313942 6.501701 259  
#[15] {default=no,loan=FALSE,poutcome=success,cellContact=TRUE,season=summer}                       => {respondedYes=TRUE} 0.006322033 0.7275449  0.008689544 6.538378 243  
#[16] {default=no,loan=FALSE,poutcome=success,cellContact=TRUE,season=summer,previousContact=FALSE} => {respondedYes=TRUE} 0.006322033 0.7275449  0.008689544 6.538378 243

#-------------------------------------------------------------------------------
# Response: Based on the results above, the previous marketing campaign had best
#           luck gaining subscribers to term deposits during the summer and with
#           people who have previously subscribed. It also seems that not having
#           been previously contacted (i.e. during a previous campaign)
#           frequently appears in the top rules as well. This could support an
#           improvement in the current marketing campaign compared to the previous.
#           the other two items commonly found in the rules are individuals not owning
#           a personal loan, and people being contacted on their cellular device
#           versus a telephone.

# Inference: It would seem that the individuals who did subscribe during this 
#            campaign are individuals who were not contacted during a previous
#            campaign, but have also already subscribed previously. It would seem
#            campaigns should occur specifically during the summer as that's when
#            most people seemed to have subscribed. They should also refine their
#            focus on people who do not have current personal loans they are paying on
#            (as well as ensure candidates have not previously defaulted on loans).
#            contacting by cell also seems to have a contribution to subscribers;
#            perhaps it simply signifies a sign a wealth around those particular
#            individuals? Difficult to infer on this detail. 

# Model:    It would seem that these rules are considerably dependable as the
#           confidence level is moderately high, but more importantly the lift
#           scores are much greater than 1, signifying that the antecedent (left-hand-side)
#           and the consequent (right-hand-side) do share a greater magnitude of
#           dependency. 
#-------------------------------------------------------------------------------