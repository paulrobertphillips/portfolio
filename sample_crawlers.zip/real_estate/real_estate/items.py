# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy.loader.processors import MapCompose, Join

## Input Processes
# Create process for removing whitespace from description attributes extracted
def description_in(description_value):
    return description_value.strip()

## Output Processes
def description_out(description_value):
    # First isolate labels (known to be first 3 elements after looking at results)
    labels = description_value[0:3]
    values = description_value[3:]
    output = {
        labels[0]: "".join(values[0]), # Beds: More straightforward since there aren't half beds (will always be integer)
        labels[1]: " ".join(values[1:-1]), # Baths: Ex: {'Baths': '2'} OR {'Baths': '2 F 1 1/2'}
        labels[2]: "".join(values[-1]), # Property Sq Ft, always comes at the end of list
    }
    return output

class RealEstateItem(scrapy.Item):
    # define the fields for your item here like:
    name = scrapy.Field(output_processor=Join()) # Join() converts lists into a string
    description = scrapy.Field(
        input_processor=MapCompose(description_in), # Tells scrapy to apply input processor to attribute after item is yielded
        output_processor=description_out, # Tells scrapy to apply output processor to attribute after item is yielded
    ) 
    price = scrapy.Field(output_processor=Join()) # Join() converts lists into a string
    agency = scrapy.Field(output_processor=Join()) # Join() converts lists into a string
