#==Modules==
import scrapy
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor # Used to define what links crawler should follow

# Import Items class defined in items.py
from real_estate.items import RealEstateItem
from scrapy.loader import ItemLoader

#==Variables==
class ListingsSpider(CrawlSpider):
    name = 'listings_crawl'
    allowed_domains = ['arizonarealestate.com']
    start_urls = [
        'https://arizonarealestate.com',
    ]
    # Constraints for link crawling
    rules = (
        Rule(
            LinkExtractor(
                restrict_xpaths=(
                    "//section[@class='section-city-list']" # Tells crawler to only follow links in this section of page
                )
            ),
            callback="parse", # parse function defined below
            follow=True, # follow links discovered in specified section
        ),
    )

    def parse(self, response):
        gallery = response.xpath('//div[@class="si-listings-column"]')
        for listing in gallery:
            # Initialize items class
            # item = RealEstateItem()
            item = ItemLoader(
                item=RealEstateItem(), 
                response=response,
                selector=listing
            )

            # Note: need to add xpath queries & name of attribute to assign output to ItemLoader object instance
            # Note: statement below offers equivalent results to the single statement that utilizes the pipeline operator
            # item['name'] = listing.xpath(
            #     './/div[@class="si-listing__title-main"]/text() | .//div[@class="si-listing__neighborhood"]/span[@class="si-listing__neighborhood-place"]/text()').getall()
            item.add_xpath('name', './/div[@class="si-listing__title-main"]/text()')
            item.add_xpath('name', './/div[@class="si-listing__neighborhood"]/span[@class="si-listing__neighborhood-place"]/text()')

            # Extract targeted items
            # item['description'] = listing.xpath(
            #     './/div[@class="si-listing__info"]//div[@class="si-listing__info-label"]/text() | .//div[@class="si-listing__info"]//div[@class="si-listing__info-value"]/descendant::*/text()').getall() # Second part of query returns text from all the children & grandchildren of div tag regardless of the tag type
            item.add_xpath('description', './/div[@class="si-listing__info"]//div[@class="si-listing__info-label"]/text()')
            item.add_xpath('description', './/div[@class="si-listing__info"]//div[@class="si-listing__info-value"]/descendant::*/text()')
            
            # Statements below are equivalent to ones commented out but now utilize Scrapy's item loader
            # item['price'] = listing.xpath(
            #     './/div[@class="si-listing__photo-price"]/span/text()').get()
            # item['agency'] = listing.xpath(
            #     './/div[@class="si-listing__footer"]/div/text()').get()
            item.add_xpath('price', './/div[@class="si-listing__photo-price"]/span/text()')
            item.add_xpath('agency', './/div[@class="si-listing__footer"]/div/text()')
            
            # Return item so that scrapy can further use it
            #yield item
            yield item.load_item() # triggers event on items extracted

            # Check to see if there's another page to visit
            next_page = response.xpath('//a[@class="js-page-link"]/@href').get()

            # Tell scrapy to follow link if there is another page
            if next_page:
                # Call on parse method recursively
                yield response.follow(next_page, callback=self.parse)
