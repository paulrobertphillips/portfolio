# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter # Grabs fields from item
from scrapy.exceptions import DropItem

class ClassifiedsRemoveDuplicatesPipeline:
    def __init__(self):
        self.titles_seen = set()

    def process_item(self, item, spider):
        adapter = ItemAdapter(item)
        # first check that title is in adapter keys
        if adapter.get('title'):
            if adapter['title'] in self.titles_seen:
                raise DropItem(f'Duplicate ad detected: {item}')
            else:
                self.titles_seen.add(adapter['title'])
                return item
        else:
            raise DropItem(f'Ad missing title detected: {item}')
        
class ClassifiedsRemoveNoPhonesPipeline:
    def process_item(self, item, spider):
        adapter = ItemAdapter(item)

        # Check if mobile or landline can be found in add
        if not adapter.get('landline') and not adapter.get('mobile'):
            raise DropItem(f'Ad with no contact info was detected: {item}')
        return item
