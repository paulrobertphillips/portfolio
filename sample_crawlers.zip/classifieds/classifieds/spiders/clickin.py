import scrapy
from classifieds.items import ClassifiedsItem
from scrapy.loader import ItemLoader
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

class ClickinSpider(CrawlSpider):
    name = 'clickin'
    allowed_domains = ['click.in']
    start_urls = ['https://www.click.in/automobiles-ctgid150']

    # Define rule to find links of interest
    # Note: rules are stored as tuples
    rules = (
        Rule(
            LinkExtractor(
                restrict_xpaths=(
                    '//div[@id="classifieds_list"]', # only need to point crawler to the target section!
                )
            ),
            callback="parse", # name of function defined below
            follow=True, # need to follow links that are returned back to us so they can be processed!
        ),
    )

    def parse(self, response):
        # Init item loader
        item = ItemLoader(
            item=ClassifiedsItem(),
            response=response,
            selector=response, # for this we need entire HTML of page!!
        )

        # Add XPaths for target items on each posting
        item.add_xpath("title", ".//h1[@class='clickin-post-title']/text()")
        item.add_xpath("locality", ".//td[contains(div,'Locality')]/div[@class='clickin-post-blackbold']/text()")
        item.add_xpath("address", ".//div[div='Address']/div/p/text()") # says go to any div element that contains a div element with value 'Address'
        item.add_xpath("landline", ".//div[contains(div,'Landline')]/div[@class='clickin-post-blackbold']/text()")
        item.add_xpath("mobile", ".//div[contains(div,'Mobile')]/div[@class='clickin-post-blackbold']/text()")
        item.add_xpath("description", ".//div[@class='clickin-description']//h2/text()")
        item.add_xpath("price", ".//td[contains(div, 'Price')]/div[@class='clickin-post-blackbold']/text()")

        # Return items yielded
        yield item.load_item()
