# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy.loader.processors import Join, MapCompose

## Input Processors
def clean_out(string):
    return string[0] \
        .replace('\t', '') \
        .replace('\n', '') \
        .replace("u'\xa0", u' ') \
        .strip('\t')

class ClassifiedsItem(scrapy.Item):
    # define the fields for your item here like:
    title = scrapy.Field(output_processor=clean_out)
    locality = scrapy.Field(output_processor=clean_out)
    address = scrapy.Field(output_processor=clean_out)
    landline = scrapy.Field(output_processor=clean_out)
    mobile = scrapy.Field(output_processor=clean_out)
    description = scrapy.Field(output_processor=clean_out)
    price = scrapy.Field(output_processor=clean_out)
