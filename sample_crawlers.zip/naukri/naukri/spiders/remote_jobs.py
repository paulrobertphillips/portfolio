import scrapy
import json
from naukri.items import NaukriItem
from scrapy.loader import ItemLoader
from math import ceil

class RemoteJobsSpider(scrapy.Spider):
    name = 'remote_jobs'
    allowed_domains = ['naukri.com']
    start_urls = [
        'https://www.naukri.com/jobapi/v3/search?noOfResults=20&urlType=search_by_keyword&searchType=adv'
                  '&keyword=remote&pageNo=2&seoKey=remote-jobs&src=discovery_trendingWdgt_homepage_srch&latLong='
    ]

    # Create page attribute in class
    page = 1

    def parse(self, response):
        # Holds JSON response content converted to a dictionary
        payload = json.loads(response.body) # JSON data will be stored under body attribute
        # Grab total number of job lists
        total = payload['noOfJobs']
        # Establish target job listing count
        #page_count = ceil(total / 20)
        page_count = 2

        # Note: listings under 'jobDetails' key are stored as a JSON array
        # (which gets converted to a list), need to iterate over list!
        for j in payload['jobDetails']:
            # Intialize instance of item loader
            i = ItemLoader(item=NaukriItem())

            # Note: not using XPath with JSON object!
            # Just use .add_value() method
            i.add_value('title', j['title'])
            i.add_value('company', j['companyName'])
            i.add_value('description', j['jobDescription'])
            i.add_value('location', ( x['label'] for x in j['placeholders'] if x['type'] == 'location'))
            i.add_value('salary', ( x['label'] for x in j['placeholders'] if x['type'] == 'salary' ))
            i.add_value('date', j['createdDate'])

            yield i.load_item()

            # Iterate over first 10 pages of results
            while self.page <= page_count:
                # Update page count
                self.page += 1

                # Update base url
                base_url = 'https://www.naukri.com/jobapi/v3/search?noOfResults=20&urlType=search_by_keyword&searchType' \
                       '=adv&keyword=remote&pageNo={' \
                       '}&seoKey=remote-jobs&src=discovery_trendingWdgt_homepage_srch&latLong='.format(self.page)
                
                # Follow new URL
                yield response.follow(base_url, callback=self.parse)