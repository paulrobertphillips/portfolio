# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy
from datetime import date
from scrapy.loader.processors import MapCompose, Join
from w3lib.html import remove_tags # built-in function for removing HTML tags

## Input Processors
def date_out(date_value):
    # Currently stored in milliseconds, store as seconds
    date_value = date_value / 1000
    return str(date.fromtimestamp(date_value))

## Output Processors

class NaukriItem(scrapy.Item):
    # Note: Output Processor converts each item from list to single string
    # Note: We use () for Join since it's not passed to the MapCompose object (e.g., not iterated on)
    # define the fields for your item here like:
    title = scrapy.Field(output_processor=Join(),)
    company = scrapy.Field(output_processor=Join(),)
    description = scrapy.Field(
        input_processor=MapCompose(remove_tags),
        output_processor=Join()
    )
    location = scrapy.Field(output_processor=Join(),)
    salary = scrapy.Field(output_processor=Join(),)
    date = scrapy.Field(
        input_processor=MapCompose(date_out),
        output_processor=Join(),
    )