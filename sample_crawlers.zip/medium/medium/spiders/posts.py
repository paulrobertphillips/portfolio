import scrapy
from selenium import webdriver
import time
from scrapy.loader import ItemLoader
from scrapy.selector import Selector
from medium.items import MediumItem

class PostsSpider(scrapy.Spider):
    name = 'posts'
    allowed_domains = ['medium.com']
    start_urls = ['https://medium.com/']

    """
    Note: when using Selenium, we are not interested
    in response object returned by scrapy; instead,
    need to define custom response object
    """
    def parse(self, r):
        options = webdriver.FirefoxOptions()
        options.headless = True
        driver = webdriver.Firefox(options=options)
        driver.get(self.start_urls[0])
        # Static wait statement
        driver.implicitly_wait(5)
        # Intialize scroll iteration tracker
        i = 1
        num_scrolls = 10
        # Need current height of page so that we can
        # scroll downwards from current position
        last_height = driver.execute_script(
            # Use JavaScript function to retrieve current height
            "return document.body.scrollHeight"
        )
        # Controlling for while website can still be scrolled down
        # and for scroll limit
        while True and i <= num_scrolls:
            # Scroll config (x, y) layout => 'x' is for horizontal scrolling
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(3)
            new_height = driver.execute_script("return document.body.scrollHeight")
            # Check if page has reached footer (cannot scroll farther)
            if new_height == last_height:
                break # break from loop
            # Otherwise update tracker
            last_height = new_height

            # Define custom response variable (store page's HTML)
            response = driver.page_source # stored as string

            # Convert reponse variable to a Selector
            selector = Selector(text=response)

            # Isolate containers hosting articles
            containers = selector.xpath("//section//div[@class='ae cx']")
            
            # Iterate through containers
            for c in containers:
                item = ItemLoader(
                    item=MediumItem,
                    response=response,
                    selector=c
                )
                item.add_xpath("title", ".//h2/text()")
                item.add_xpath("excerpt", ".//h3/text()")
                item.add_xpath("link", ".//a[h2]/@href")
                yield item.load_item()
            # Increment iterable
            i += 1
            # Quite driver
            driver.quit()


