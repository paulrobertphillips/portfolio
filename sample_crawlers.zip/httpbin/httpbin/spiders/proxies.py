import scrapy
import json

class ProxiesSpider(scrapy.Spider):
    name = 'proxies'
    allowed_domains = ['httpbin.org']
    start_urls = ['http://httpbin.org/ip'] # endpoint returns IP address of request

    def parse(self, response):
        payload = json.loads(response.body)
        yield(payload)
