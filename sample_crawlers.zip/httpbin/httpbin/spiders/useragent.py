import scrapy
import json

class UseragentSpider(scrapy.Spider):
    name = 'useragent'
    allowed_domains = ['httpbin.org']
    start_urls = ['http://httpbin.org/user-agent'] # endpoint returns user-agent of request

    def parse(self, response):
        payload = json.loads(response.body)
        yield(payload)
