# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy.loader.processors import Join

## Input Processors

## Output Processors
def extract_out(string):
    return string[0] # Announced date field sometimes has 1+ lines, only need first


class PhoneModelsItem(scrapy.Item):
    # define the fields for your item here like:
    title = scrapy.Field(output_processor=Join())
    announced = scrapy.Field(output_processor=extract_out)
