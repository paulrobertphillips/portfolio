/* 
	Author: Paul R Phillips
	Course: IST659 M400
	Date: 12/13/2020

	File: Database Stored Procedure Use Case Samples

	Description:
		This file contains examples of how stored procedures
		can be used.
*/

-- Update market info
EXEC pjt.UpdateMarketInfo @FMID=1003516, @StreetAddress = '1234 Holiday Dr.', @MarketDay='Thu'
SELECT
	pjt.Market.MarketName AS MarketName
	, pjt.Market.StreetAddress AS StreetAddress
	, pjt.Market.MarketDay AS MarketDay
	, pjt.MarketInfoUpdate.updateTime AS updateTime
FROM pjt.Market 
LEFT JOIN pjt.MarketInfoUpdate ON pjt.MarketInfoUpdate.MarketID = pjt.Market.MarketID
WHERE pjt.Market.FMID = 1003516
-- Change back to original
EXEC pjt.UpdateMarketInfo @FMID=1003516, @StreetAddress = '1500 W. Berwyn Ave.', @MarketDay='Wed'
GO

-----------------------------------------------------------------------------------------------------------------------------------------

-- Add new payment type for market
EXEC pjt.AddMarketPaymentType 'Cash', 1003516
SELECT 
	FMID
	, PayForm
FROM pjt.MarketMetaData
JOIN pjt.InspectIncomeCityProducts ON pjt.InspectIncomeCityProducts.MarketID = pjt.MarketMetaData.MarketID
WHERE FMID = 1003516
DELETE pjt.MarketPayment WHERE pjt.MarketPayment.PaymentID = (SELECT pjt.Payment.PaymentID FROM pjt.Payment WHERE pjt.Payment.AcceptedPayForm = 'Cash')
DELETE pjt.Payment WHERE pjt.Payment.AcceptedPayForm = 'Cash'
GO

-----------------------------------------------------------------------------------------------------------------------------------------

-- Add new product source for market
EXEC pjt.AddMarketProductSource 'HomeGrown', 1003516
SELECT 
	FMID
	, ProductSource
FROM pjt.MarketMetaData
JOIN pjt.InspectIncomeCityProducts ON pjt.InspectIncomeCityProducts.MarketID = pjt.MarketMetaData.MarketID
WHERE FMID = 1003516
DELETE pjt.MarketProductSource WHERE pjt.MarketProductSource.ProductSourceID = (SELECT pjt.ProductSource.ProductSourceID FROM pjt.ProductSource WHERE pjt.ProductSource.ProductSource = 'HomeGrown')
DELETE pjt.ProductSource WHERE pjt.ProductSource.ProductSource = 'HomeGrown'
GO

-----------------------------------------------------------------------------------------------------------------------------------------

-- Add new veggie product for market
EXEC pjt.AddMarketVegetarianProduct 'Carrots', 1003516
SELECT 
	FMID
	, Veggies
FROM pjt.MarketMetaData
JOIN pjt.InspectIncomeCityProducts ON pjt.InspectIncomeCityProducts.MarketID = pjt.MarketMetaData.MarketID
WHERE FMID = 1003516
DELETE pjt.MarketVegetarianProduct WHERE pjt.MarketVegetarianProduct.VegetarianProductID = (SELECT pjt.VegetarianProduct.VegetarianProductID FROM pjt.VegetarianProduct WHERE pjt.VegetarianProduct.VegetarianProduce = 'Carrots')
DELETE pjt.VegetarianProduct WHERE pjt.VegetarianProduct.VegetarianProduce = 'Carrots'
GO

-----------------------------------------------------------------------------------------------------------------------------------------

-- Add new animal product for market
EXEC pjt.AddMarketAnimalProduct 'Yogurt', 1003516
SELECT 
	FMID
	, AnimalProduce
FROM pjt.MarketMetaData
JOIN pjt.InspectIncomeCityProducts ON pjt.InspectIncomeCityProducts.MarketID = pjt.MarketMetaData.MarketID
WHERE FMID = 1003516
DELETE pjt.MarketAnimalProduct WHERE pjt.MarketAnimalProduct.AnimalProductID = (SELECT pjt.AnimalProduct.AnimalProductID FROM pjt.AnimalProduct WHERE pjt.AnimalProduct.AnimalProduct = 'Yogurt')
DELETE pjt.AnimalProduct WHERE pjt.AnimalProduct.AnimalProduct = 'Yogurt'
GO

-----------------------------------------------------------------------------------------------------------------------------------------

-- Add new meat product for market
EXEC pjt.AddMarketMeat'Turkey', 1003516
SELECT 
	FMID
	, Meats
FROM pjt.MarketMetaData
JOIN pjt.InspectIncomeCityProducts ON pjt.InspectIncomeCityProducts.MarketID = pjt.MarketMetaData.MarketID
WHERE FMID = 1003516
DELETE pjt.MarketMeat WHERE pjt.MarketMeat.MeatID = (SELECT pjt.Meat.MeatID FROM pjt.Meat WHERE pjt.Meat.Meats = 'Turkey')
DELETE pjt.Meat WHERE pjt.Meat.Meats = 'Turkey'
GO

-----------------------------------------------------------------------------------------------------------------------------------------

-- Add new beverage product for market
EXEC pjt.AddMarketBeverage 'Craft Beer', 1003516
SELECT 
	FMID
	, Beverages
FROM pjt.MarketMetaData
JOIN pjt.InspectIncomeCityProducts ON pjt.InspectIncomeCityProducts.MarketID = pjt.MarketMetaData.MarketID
WHERE FMID = 1003516
DELETE pjt.MarketBeverage WHERE pjt.MarketBeverage.BeverageID = (SELECT pjt.Beverage.BeverageID FROM pjt.Beverage WHERE pjt.Beverage.Beverages = 'Craft Beer')
DELETE pjt.Beverage WHERE pjt.Beverage.Beverages = 'Craft Beer'
GO

-----------------------------------------------------------------------------------------------------------------------------------------

-- Add new condiment product for market
EXEC pjt.AddMarketCondiment 'Mustard', 1003516
SELECT 
	FMID
	, Condiments
FROM pjt.MarketMetaData
JOIN pjt.InspectIncomeCityProducts ON pjt.InspectIncomeCityProducts.MarketID = pjt.MarketMetaData.MarketID
WHERE FMID = 1003516
DELETE pjt.MarketCondiment WHERE pjt.MarketCondiment.CondimentID = (SELECT pjt.Condiment.CondimentID FROM pjt.Condiment WHERE pjt.Condiment.Condiments = 'Mustard')
DELETE pjt.Condiment WHERE pjt.Condiment.Condiments = 'Mustard'
GO

-----------------------------------------------------------------------------------------------------------------------------------------

-- Add new misc product for market
EXEC pjt.AddMarketMiscProduct 'Basket', 1003516
SELECT 
	FMID
	, MiscProducts
FROM pjt.MarketMetaData
JOIN pjt.InspectIncomeCityProducts ON pjt.InspectIncomeCityProducts.MarketID = pjt.MarketMetaData.MarketID
WHERE FMID = 1003516
DELETE pjt.MarketMiscProduct WHERE pjt.MarketMiscProduct.MiscProductID = (SELECT pjt.MiscProduct.MiscProductID FROM pjt.MiscProduct WHERE pjt.MiscProduct.MiscProducts = 'Basket')
DELETE pjt.MiscProduct WHERE pjt.MiscProduct.MiscProducts = 'Basket'
GO

-----------------------------------------------------------------------------------------------------------------------------------------

-- Adding new market media
EXEC pjt.AddMarketMedia @FMID=1003516, @WebsiteURL='www.ThisIsAURL.com', @FaceBook='FaceInABook' 
-- Ensure controls are working proper (works great!)
--EXEC pjt.AddMarketMedia @FMID=1003516

SELECT 
	FMID
	, WebsiteURL
	, Facebook
	, Twitter
	, YouTube
FROM pjt.MarketMetaData
WHERE FMID = 1003516
-- Change back to original
EXEC pjt.AddMarketMedia @FMID=1003516, @WebsiteURL='http://www.andersonville.org', @FaceBook='https://www.facebook.com/andersonville?ref=bookmarks'
GO

-----------------------------------------------------------------------------------------------------------------------------------------

