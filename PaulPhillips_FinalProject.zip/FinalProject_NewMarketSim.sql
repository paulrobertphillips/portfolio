/* 
	Author: Paul R Phillips
	Course: IST659 M400
	Date: 12/13/2020

	File: Simulate adding a new market with stored procedures.

	Description:
		This includes all market details.
*/

-- Will actually include new market and will add associated products at the end of this script
EXEC pjt.AddNewMarket
	@FMID=1012680
	, @MarketName='Lisle French Market'
	, @StreetAddress='Garfield Ave. North of Burlington'
	, @City='Lisle'
	, @County='DuPage'
	, @AddressState='Illinois'
	, @PostalCode='60532'
	, @Longitude=-88.076118
	, @Latitude=41.799606
	, @SeasonStartDate='6/11/2016'
	, @SeasonEndDate='9/3/2016'
	, @MarketDay='Sat'
	, @BusinessOpen='08:00:00'
	, @BusinessClose='13:00:00'
GO

-- Add new payment type for market
EXEC pjt.AddMarketPaymentType 'Credit', 1012680
GO

-- Add new product source for market
EXEC pjt.AddMarketProductSource 'Organic', 1012680
GO

-- Add new veggie product for market
EXEC pjt.AddMarketVegetarianProduct 'Tofu', 1012680
GO

-- Add new animal product for market
EXEC pjt.AddMarketAnimalProduct 'Eggs', 1012680
GO

-- Add new meat product for market
EXEC pjt.AddMarketMeat 'Seafood', 1012680
GO

-- Add new beverage product for market
EXEC pjt.AddMarketBeverage 'Juices', 1012680
GO

-- Add new condiment product for market
EXEC pjt.AddMarketCondiment 'Herbs', 1012680
GO

-- Add new misc product for market
EXEC pjt.AddMarketMiscProduct 'Flowers', 1012680
GO

-- Add new market media
EXEC pjt.AddMarketMedia 
	@FMID=1012680
	, @WebsiteURL='http://www.bensidounmidwestmarkets.com/'
	, @FaceBook='https://facebook.com/GenevaFrenchMarket' 
	, @Twitter='https://twitter.com/BensidounMarket'
GO

-- Add new market area demographics
EXEC pjt.AddMarketAreaDemographics
	@FMID=1012680
	, @County='DuPage'
	, @AddressState='Illinois'
	, @PerCapita=38570
	, @MedianHouseholdIncome=78487
	, @MedianFamilyIncome=95208 
	, @AreaPopulation=922803 
	, @NumberOfHouseholds=336028 
GO

-- Check work
SELECT * 
FROM pjt.InspectIncomeCityProducts 
WHERE pjt.InspectIncomeCityProducts.MarketID = (SELECT pjt.MarketMetaData.MarketID 
												FROM pjt.MarketMetaData 
												WHERE pjt.MarketMetaData.FMID = 1012680)

SELECT *
FROM pjt.MarketMetaData
WHERE pjt.MarketMetaData.FMID = 1012680



-----------------------------------------------------------------------------------------------------------------------------------------