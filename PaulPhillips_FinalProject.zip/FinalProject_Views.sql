/* 
	Author: Paul R Phillips
	Course: IST659 M400
	Date: 12/13/2020

	File: Database Views

	Description:
		This file contains all the appropriate views
		which users can query on to answer business 
		questions related to database. The views 
		simplify abstraction requirements in order to
		properly connect needed tables and components in 
		various types of queries. 
	
	Note: 
		Views have been set up to where user can merge 
		columns from both if they choose. Since 
		applications such as "R" or "Python" could be
		querying from this database I wanted the feel
		of doing so to be similar to that of a simpler
		design.
*/

-- Create View that captures city demographics and available market products
DROP VIEW pjt.InspectIncomeCityProducts
GO
CREATE VIEW pjt.InspectIncomeCityProducts AS
	SELECT 
	pjt.City.City AS City
	, pjt.Payment.AcceptedPayForm as PayForm
	, pjt.ProductSource.ProductSource as ProductSource
	, pjt.VegetarianProduct.VegetarianProduce as Veggies
	, pjt.AnimalProduct.AnimalProduct as AnimalProduce
	, pjt.Meat.Meats as Meats
	, pjt.Beverage.Beverages as Beverages
	, pjt.Condiment.Condiments as Condiments
	, pjt.MiscProduct.MiscProducts as MiscProducts
	, pjt.Demographic.PerCapita AS PerCapita
	, pjt.Demographic.MedianHouseholdIncome AS MedianHouseholdIncome
	, pjt.Demographic.MedianFamilyIncome AS MedianFamilyIncome
	, pjt.Demographic.AreaPopulation AS AreaPopulation
	, pjt.Demographic.NumberOfHouseholds AS NumberOfHouseholds
	, pjt.Market.MarketID AS MarketID
	FROM pjt.City
	JOIN pjt.MarketCity ON pjt.City.CityID = pjt.MarketCity.CityID
	LEFT JOIN pjt.Market ON pjt.Market.MarketID = pjt.MarketCity.MarketID
	JOIN pjt.MarketPayment ON pjt.Market.MarketID = pjt.MarketPayment.MarketID
	JOIN pjt.MarketProductSource ON pjt.Market.MarketID = pjt.MarketProductSource.MarketID
	JOIN pjt.MarketVegetarianProduct ON pjt.Market.MarketID = pjt.MarketVegetarianProduct.MarketID
	JOIN pjt.MarketAnimalProduct ON pjt.Market.MarketID = pjt.MarketAnimalProduct.MarketID
	JOIN pjt.MarketMeat ON pjt.Market.MarketID = pjt.MarketMeat.MarketID
	JOIN pjt.MarketBeverage ON pjt.Market.MarketID = pjt.MarketBeverage.MarketID
	JOIN pjt.MarketCondiment ON pjt.Market.MarketID = pjt.MarketCondiment.MarketID
	JOIN pjt.MarketMiscProduct ON pjt.Market.MarketID = pjt.MarketMiscProduct.MarketID
	JOIN pjt.MarketDemographic ON pjt.MarketDemographic.MarketID = pjt.Market.MarketID
	LEFT JOIN pjt.Payment ON pjt.Payment.PaymentID = pjt.MarketPayment.PaymentID
	LEFT JOIN pjt.ProductSource ON pjt.ProductSource.ProductSourceID = pjt.MarketProductSource.ProductSourceID
	LEFT JOIN pjt.VegetarianProduct ON pjt.VegetarianProduct.VegetarianProductID = pjt.MarketVegetarianProduct.VegetarianProductID
	LEFT JOIN pjt.AnimalProduct ON pjt.AnimalProduct.AnimalProductID = pjt.MarketAnimalProduct.AnimalProductID
	LEFT JOIN pjt.Meat ON pjt.Meat.MeatID = pjt.MarketMeat.MeatID
	LEFT JOIN pjt.Beverage ON pjt.Beverage.BeverageID = pjt.MarketBeverage.BeverageID
	LEFT JOIN pjt.Condiment ON pjt.Condiment.CondimentID = pjt.MarketCondiment.CondimentID
	LEFT JOIN pjt.MiscProduct ON pjt.MiscProduct.MiscProductID = pjt.MarketMiscProduct.MiscProductID
	LEFT JOIN pjt.Demographic ON pjt.Demographic.DemographicID = pjt.MarketDemographic.DemographicID
GO

-- Create view of all market metadata
DROP VIEW pjt.MarketMetaData
GO
CREATE VIEW pjt.MarketMetaData AS
	SELECT
		pjt.Market.MarketID AS MarketID
		, pjt.Market.FMID AS FMID
		, pjt.Market.MarketName AS MarketName
		, pjt.Market.StreetAddress AS StreetAddress
		, pjt.City.City AS City
		, pjt.County.County AS County
		, pjt.AddressState.AddressState AS MarketState
		, pjt.PostalCode.PostalCode AS PostalCode
		, pjt.Coordinate.Longitude AS Longitude
		, pjt.Coordinate.Latitude AS Latitude
		, pjt.Market.SeasonStartDate AS SeasonStartDate
		, pjt.Market.SeasonEndDate AS SeasonEndDate
		, pjt.Market.MarketDay AS MarketDay
		, pjt.Market.BusinessOpen AS OpenHours
		, pjt.Market.BusinessClose AS CloseHours
		, pjt.Media.WebsiteURL AS WebsiteURL
		, pjt.Media.FaceBook AS FaceBook
		, pjt.Media.Twitter AS Twitter
		, pjt.Media.YouTube AS YouTube
		, pjt.MarketInfoUpdate.updateTime AS LastUpdate
	FROM pjt.Market
	JOIN pjt.MarketCity ON pjt.Market.MarketID = pjt.MarketCity.MarketID
	JOIN pjt.MarketCounty ON pjt.Market.MarketID = pjt.MarketCounty.MarketID
	JOIN pjt.MarketState ON pjt.Market.MarketID = pjt.MarketState.MarketID
	JOIN pjt.MarketPostalCode ON pjt.Market.MarketID = pjt.MarketPostalCode.MarketID
	LEFT JOIN pjt.City ON pjt.MarketCity.CityID = pjt.City.CityID
	LEFT JOIN pjt.County ON pjt.MarketCounty.CountyID = pjt.County.CountyID
	LEFT JOIN pjt.AddressState ON pjt.AddressState.AddressStateID = pjt.MarketState.AddressStateID
	LEFT JOIN pjt.PostalCode ON pjt.PostalCode.PostalCodeID = pjt.MarketPostalCode.PostalCodeID
	LEFT JOIN pjt.Coordinate ON pjt.Coordinate.MarketID = pjt.Market.MarketID
	LEFT JOIN pjt.Media ON pjt.Media.MarketID = pjt.Market.MarketID
	LEFT JOIN pjt.MarketInfoUpdate ON pjt.MarketInfoUpdate.MarketID = pjt.Market.MarketID
GO