/* 
	Author: Paul R Phillips
	Course: IST659 M400
	Date: 12/13/2020

	File: DDL
	Description:
		This file contains all the code needed to physically create the tables
		from the logical model for my project

	Developer Note:
		If the tables were not called by schema dropping tables would look like this:
		DROP TABLE IF EXISTS <table_name>
*/

-- Begin: Code for dropping tables

/* Begin: Drop Associative Tables */

-- Drop Table: pjt.MarketPayment
-- FK on pjt.Payment, pjt.Market
DROP TABLE pjt.MarketPayment

-- Drop Table: pjt.MarketPayment
-- FK on pjt.ProductSource, pjt.Market
DROP TABLE pjt.MarketProductSource

-- Drop Table: pjt.MarketVegetarianProduct
-- FK on pjt.VegetarianProduct, pjt.Market
DROP TABLE pjt.MarketVegetarianProduct

-- Drop Table: pjt.MarketAnimalProduct
-- FK on pjt.AnimalProduct, pjt.Market
DROP TABLE pjt.MarketAnimalProduct

-- Drop Table: pjt.MarketMeat
-- FK on pjt.Meat, pjt.Market
DROP TABLE pjt.MarketMeat

-- Drop Table: pjt.MarketBeverage
-- FK on pjt.Beverage, pjt.Market
DROP TABLE pjt.MarketBeverage

-- Drop Table: pjt.MarketCondiment
-- FK on pjt.Condiment, pjt.Market
DROP TABLE pjt.MarketCondiment

-- Drop Table: pjt.MarketMiscProduct
-- FK on pjt.MiscProduct, pjt.Market
DROP TABLE pjt.MarketMiscProduct

-- Drop Table: pjt.MarketDemographic
-- FK on pjt.Demographic, pjt.Market
DROP TABLE pjt.MarketDemographic

-- Drop Table: pjt.MarketCity
-- FK on pjt.City, pjt.Market
DROP TABLE pjt.MarketCity

-- Drop Table: pjt.MarketCounty
-- FK on pjt.County, pjt.Market
DROP TABLE pjt.MarketCounty

-- Drop Table: pjt.MarketState
-- FK on pjt.AddressState, pjt.Market
DROP TABLE pjt.MarketState

-- Drop Table: pjt.MarketPostalCode
-- FK on pjt.PostalCode, pjt.Market
DROP TABLE pjt.MarketPostalCode

/* End: Drop Associative Tables */


-- Drop Table: pjt.Payment
-- No FK's
DROP TABLE pjt.Payment

-- Drop Table: pjt.ProductSource
-- No FK's
DROP TABLE pjt.ProductSource

-- Drop Table: pjt.VegetarianProduct
-- No FK's
DROP TABLE pjt.VegetarianProduct

-- Drop Table: pjt.AnimalProduct
-- No FK's
DROP TABLE pjt.AnimalProduct

-- Drop Table: pjt.Meat
-- No FK's
DROP TABLE pjt.Meat

-- Drop Table: pjt.Beverage
-- No FK's
DROP TABLE pjt.Beverage

-- Drop Table: pjt.Condiment
-- No FK's
DROP TABLE pjt.Condiment

-- Drop Table: pjt.MiscProduct
-- No FK's
DROP TABLE pjt.MiscProduct

-- Drop Table: pjt.MiscProduct
-- No FK's
DROP TABLE pjt.Demographic

-- Drop Table: pjt.City
-- No FK's
DROP TABLE pjt.City

-- Drop Table: pjt.County
-- No FK's
DROP TABLE pjt.County

-- Drop Table: pjt.AddressState
-- No FK's
DROP TABLE pjt.AddressState

-- Drop Table: pjt.PostalCode
-- No FK's
DROP TABLE pjt.PostalCode

-- Drop Table: pjt.MarketInfoUpdate
-- FK on pjt.Market
DROP TABLE pjt.MarketInfoUpdate

-- Drop Table: pjt.Media
-- FK on pjt.Market
DROP TABLE pjt.Media

-- Drop Table: pjt.Coordinate
-- FK on pjt.Market
DROP TABLE pjt.Coordinate

-- Drop Table: pjt.Market
-- No FK's
DROP TABLE pjt.Market

-- End: Code for dropping tables

/* Begin: Tables NOT consisting of FK's */
-- Create Table: pjt.Payment
CREATE TABLE pjt.Payment (
	PaymentID int identity primary key
	, AcceptedPayForm varchar(15) NOT NULL
	, CONSTRAINT UK1_AcceptedPayForm UNIQUE (AcceptedPayForm)
)

-- Create Table: pjt.ProductSource
CREATE TABLE pjt.ProductSource (
	ProductSourceID int identity primary key
	, ProductSource varchar(50) NOT NULL
	, CONSTRAINT UK1_ProductSource UNIQUE (ProductSource)
)


-- Create Table: pjt.VegetarianProduct
CREATE TABLE pjt.VegetarianProduct (
	VegetarianProductID int identity primary key
	, VegetarianProduce varchar(50) NOT NULL
	, CONSTRAINT UK1_VegetarianProduce UNIQUE (VegetarianProduce)
)

-- Create Table: pjt.VegetarianProduct
CREATE TABLE pjt.AnimalProduct (
	AnimalProductID int identity primary key
	, AnimalProduct varchar(50) NOT NULL
	, CONSTRAINT UK1_AnimalProduct UNIQUE (AnimalProduct)
)

-- Create Table: pjt.Meat
CREATE TABLE pjt.Meat (
	MeatID int identity primary key
	, Meats varchar(50) NOT NULL
	, CONSTRAINT UK1_Meats UNIQUE (Meats)
)

-- Create Table: pjt.Beverage
CREATE TABLE pjt.Beverage (
	BeverageID int identity primary key
	, Beverages varchar(50) NOT NULL
	, CONSTRAINT UK1_Beverages UNIQUE (Beverages)
)

-- Create Table: pjt.Condiment
CREATE TABLE pjt.Condiment (
	CondimentID int identity primary key
	, Condiments varchar(50) NOT NULL
	, CONSTRAINT UK1_Condiments UNIQUE (Condiments)
)

-- Create Table: pjt.MiscProduct
CREATE TABLE pjt.MiscProduct (
	MiscProductID int identity primary key
	, MiscProducts varchar(50) NOT NULL
	, CONSTRAINT UK1_MiscProducts UNIQUE (MiscProducts)
)

-- Create Table: pjt.Demographic
CREATE TABLE pjt.Demographic (
	DemographicID int identity primary key
	, PerCapita int NOT NULL
	, MedianHouseholdIncome int NOT NULL
	, MedianFamilyIncome int NOT NULL
	, AreaPopulation int NOT NULL
	, NumberOfHouseholds int NOT NULL
	, CONSTRAINT UK1_Demographic 
		UNIQUE (PerCapita,MedianHouseholdIncome,MedianFamilyIncome,AreaPopulation,NumberOfHouseholds)
)

-- Create Table: pjt.City
CREATE TABLE pjt.City (
	CityID int identity primary key
	, City varchar(50) NOT NULL
	, CONSTRAINT UK1_City UNIQUE (City)
)

-- Create Table: pjt.County
CREATE TABLE pjt.County (
	CountyID int identity primary key
	, County varchar(50) NOT NULL
	, CONSTRAINT UK1_County UNIQUE (County)
)

-- Create Table: pjt.AddressState
CREATE TABLE pjt.AddressState (
	AddressStateID int identity primary key
	, AddressState varchar(50) NOT NULL
	, CONSTRAINT UK1_AddressState UNIQUE (AddressState)
)

-- Create Table: pjt.PostalCode
CREATE TABLE pjt.PostalCode (
	PostalCodeID int identity primary key
	, PostalCode varchar(50) NOT NULL
	, CONSTRAINT UK1_PostalCode UNIQUE (PostalCode)
)

-- Create Table: pjt.Market
CREATE TABLE pjt.Market (
	MarketID int identity primary key
	, FMID int NOT NULL
	, MarketName varchar(250) NOT NULL
	, StreetAddress varchar(250) NOT NULL
	, SeasonStartDate date NOT NULL DEFAULT GetDate()
	, SeasonEndDate	date NOT NULL DEFAULT GetDate()
	, MarketDay varchar(3)
	, BusinessOpen time NOT NULL
	, BusinessClose time NOT NULL
	, CONSTRAINT UK1_FMID UNIQUE (FMID)
)

/* End: Tables NOT consisting of FK's */

/* Begin: NON associative tables with FK's */
-- Create Table: pjt.Media
CREATE TABLE pjt.Media (
	MediaID int identity primary key
	, WebsiteURL varchar(200) 
	, FaceBook varchar(200)
	, Twitter varchar(200)
	, YouTube varchar(200)
	, MarketID int NOT NULL
	, CONSTRAINT FK1_Media FOREIGN KEY (MarketID) REFERENCES pjt.Market (MarketID)
)

-- Create Table: pjt.MarketInfoUpdate
-- Having 'updateTime' as NOT NULL could cause issues later on; be wary
CREATE TABLE pjt.MarketInfoUpdate (
	MarketInfoUpdateID int identity primary key
	,updateTime datetime NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT FK1_MarketInfoUpdate FOREIGN KEY (MarketID) REFERENCES pjt.Market (MarketID)
)

-- Create Table: pjt.Coordinate
CREATE TABLE pjt.Coordinate (
	CoordinateID int identity primary key
	, Longitude decimal(13,10) NOT NULL
	, Latitude decimal(13, 10) NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT FK1_Coordinate FOREIGN KEY (MarketID) REFERENCES pjt.Market (MarketID)
)
/* End: NON associative tables with FK's */

/* Begin: Associative tables with FK's */

-- Create Table: pjt.MarketPayment
CREATE TABLE pjt.MarketPayment (
	MarketPaymentID int identity primary key
	,PaymentID int NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT UK1_MarketPayment UNIQUE (PaymentID, MarketID)
	, CONSTRAINT FK1_vc_MarketPayment FOREIGN KEY (PaymentID) REFERENCES pjt.Payment(PaymentID)
	, CONSTRAINT FK2_vc_MarketPayment FOREIGN KEY (MarketID) REFERENCES pjt.Market(MarketID) 
)

-- Create Table: pjt.MarketProductSource
CREATE TABLE pjt.MarketProductSource (
	MarketProductSourcetID int identity primary key
	,ProductSourceID int NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT UK1_MarketProductSource UNIQUE (ProductSourceID, MarketID)
	, CONSTRAINT FK1_MarketProductSource FOREIGN KEY (ProductSourceID) REFERENCES pjt.ProductSource(ProductSourceID)
	, CONSTRAINT FK2_MarketProductSource FOREIGN KEY (MarketID) REFERENCES pjt.Market(MarketID) 
)

-- Create Table: pjt.MarketVegetarianProduct
CREATE TABLE pjt.MarketVegetarianProduct (
	MarketVegetarianProductID int identity primary key
	,VegetarianProductID int NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT UK1_MarketVegetarianProduct UNIQUE (VegetarianProductID, MarketID)
	, CONSTRAINT FK1_MarketVegetarianProduct FOREIGN KEY (VegetarianProductID) REFERENCES pjt.VegetarianProduct(VegetarianProductID)
	, CONSTRAINT FK2_MarketVegetarianProduct FOREIGN KEY (MarketID) REFERENCES pjt.Market(MarketID) 
)

-- Create Table: pjt.MarketAnimalProduct
CREATE TABLE pjt.MarketAnimalProduct (
	MarketAnimalProductID int identity primary key
	,AnimalProductID int NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT UK1_MarketAnimalProduct UNIQUE (AnimalProductID, MarketID)
	, CONSTRAINT FK1_MarketAnimalProduct FOREIGN KEY (AnimalProductID) REFERENCES pjt.AnimalProduct(AnimalProductID)
	, CONSTRAINT FK2_MarketAnimalProduct FOREIGN KEY (MarketID) REFERENCES pjt.Market(MarketID) 
)

-- Create Table: pjt.MarketMeat
CREATE TABLE pjt.MarketMeat (
	MarketMeatID int identity primary key
	,MeatID int NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT UK1_MarketMeat UNIQUE (MeatID, MarketID)
	, CONSTRAINT FK1_MarketMeat FOREIGN KEY (MeatID) REFERENCES pjt.Meat(MeatID)
	, CONSTRAINT FK2_MarketMeat FOREIGN KEY (MarketID) REFERENCES pjt.Market(MarketID) 
)

-- Create Table: pjt.MarketBeverage
CREATE TABLE pjt.MarketBeverage (
	MarketBeverageID int identity primary key
	,BeverageID int NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT UK1_MarketBeverage UNIQUE (BeverageID, MarketID)
	, CONSTRAINT FK1_MarketBeverage FOREIGN KEY (BeverageID) REFERENCES pjt.Beverage(BeverageID)
	, CONSTRAINT FK2_MarketBeverage FOREIGN KEY (MarketID) REFERENCES pjt.Market(MarketID) 
)

-- Create Table: pjt.MarketCondiment
CREATE TABLE pjt.MarketCondiment (
	MarketCondimentID int identity primary key
	,CondimentID int NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT UK1_MarketCondiment UNIQUE (CondimentID, MarketID)
	, CONSTRAINT FK1_MarketCondiment FOREIGN KEY (CondimentID) REFERENCES pjt.Condiment(CondimentID)
	, CONSTRAINT FK2_MarketCondiment FOREIGN KEY (MarketID) REFERENCES pjt.Market(MarketID) 
)

-- Create Table: pjt.MarketMiscProduct
CREATE TABLE pjt.MarketMiscProduct (
	MarketMiscProductID int identity primary key
	,MiscProductID int NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT UK1_MarketMiscProduct UNIQUE (MiscProductID, MarketID)
	, CONSTRAINT FK1_MarketMiscProduct FOREIGN KEY (MiscProductID) REFERENCES pjt.MiscProduct(MiscProductID)
	, CONSTRAINT FK2_MarketMiscProduct FOREIGN KEY (MarketID) REFERENCES pjt.Market(MarketID) 
)

-- Create Table: pjt.MarketDemographic
CREATE TABLE pjt.MarketDemographic (
	MarketDemographicID int identity primary key
	,DemographicID int NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT UK1_MarketDemographic UNIQUE (DemographicID, MarketID)
	, CONSTRAINT FK1_MarketDemographic FOREIGN KEY (DemographicID) REFERENCES pjt.Demographic(DemographicID)
	, CONSTRAINT FK2_MarketDemographic FOREIGN KEY (MarketID) REFERENCES pjt.Market(MarketID) 
)

-- Create Table: pjt.MarketCity
CREATE TABLE pjt.MarketCity (
	MarketCityID int identity primary key
	,CityID int NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT UK1_MarketCity UNIQUE (CityID, MarketID)
	, CONSTRAINT FK1_MarketCity FOREIGN KEY (CityID) REFERENCES pjt.City(CityID)
	, CONSTRAINT FK2_MarketCity FOREIGN KEY (MarketID) REFERENCES pjt.Market(MarketID) 
)

-- Create Table: pjt.MarketCounty
CREATE TABLE pjt.MarketCounty (
	MarketCountyID int identity primary key
	,CountyID int NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT UK1_MarketCounty UNIQUE (CountyID, MarketID)
	, CONSTRAINT FK1_MarketCounty FOREIGN KEY (CountyID) REFERENCES pjt.County(CountyID)
	, CONSTRAINT FK2_MarketCounty FOREIGN KEY (MarketID) REFERENCES pjt.Market(MarketID) 
)

CREATE TABLE pjt.MarketState (
	MarketStateID int identity primary key
	,AddressStateID int NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT UK1_MarketState UNIQUE (AddressStateID, MarketID)
	, CONSTRAINT FK1_MarketState FOREIGN KEY (AddressStateID) REFERENCES pjt.AddressState(AddressStateID)
	, CONSTRAINT FK2_MarketState FOREIGN KEY (MarketID) REFERENCES pjt.Market(MarketID) 
)

CREATE TABLE pjt.MarketPostalCode (
	MarketPostalCodeID int identity primary key
	,PostalCodeID int NOT NULL
	, MarketID int NOT NULL
	, CONSTRAINT UK1_MarketPostalCode UNIQUE (PostalCodeID, MarketID)
	, CONSTRAINT FK1_MarketPostalCode FOREIGN KEY (PostalCodeID) REFERENCES pjt.PostalCode(PostalCodeID)
	, CONSTRAINT FK2_MarketPostalCode FOREIGN KEY (MarketID) REFERENCES pjt.Market(MarketID) 
)

/* End: Associative tables with FK's */




