######################################################################
Date: 12/13/2020
Author: Paul R Phillips
Description:
	In this directory, you will find all the code used to build, test, and
	reconfigure the Farmer's Market database. Documentation of the project
	itself has also been included. Finally, there are files which include
	use cases for how an analyst would use the database from R, as well as
	how the database administrators would conduct database maintenance from
	MSSMS. Below you will find the list of directory components, along with
	brief descriptions of their content.

Developer Note:
	In terms of definition, I have categorized all of the tables in the database
	as the following:
		1) Tables with no dependencies (outer (source) tables, central table)
		2) Tables with dependencies (tables containing foreign keys
			that are not associative)
		3) Associative Tables (tables containing nothing more than
			index references to two or more other tables)

######################################################################

Components:
 - FinalProject_DDL.sql
	This file contains all of the code necessary for actually building
	the database in MSSMS. It includes all of the DROP and CREATE statements
	in an order that controls for table dependencies.

 - FinalProject_FailSafe_ClearTablesOfBetaData.sql
	This file was moreso of importance during the early stages of building.
	It contains the DELETE statements for all tables in the database. It 
	was used as a means of quickly erasing the intial data such that changes
	to the database design could be easily done.

 - FinalProject_ImportBetaData.sql
	This file contains all of the initial INSERT statements for the tables 
	NOT containing foreign keys (i.e. tables that don't have dependencies).

 - FinalProject_ImportBetaData_tableDependents.sql
	This file contains all of the initial INSERT statements for the tables
	that do have dependencies (including the associative tables).

 - FinalProject_NewMarketSim.sql
	This file contains a full simulation of entering all aspects of a new
	market into the database using the stored procedures. Executing this
	file is a permanent change to the actual database (I just used the 11th
	market from the original data).

 - FinalProject_SampleQueries.sql
	This file contains the sample queries that could be used to answer the
	original business questions relevant to this project. The queries leverage
	the views created for the database. There are some utility queries that were
	added here (mostly to show how stuff is actually pulled from database).

 - FinalProject_SP_UseCases.sql
	This file contains used cases for the stored procedures developed. Changes
	made are NOT permanent when this code is ran. SELECT statements will show
	that the stored procedures worked as expected, but changes are then removed
	immediately after. 

 - FinalProject_StoredProcedures.sql
	This file contains all of the necessary stored procedures for this database.
	The file contains the needed DROP and CREATE statements for each stored procedure.

 - FinalProject_Views.sql
	This file contains all of the necessary views for this database.
	This file contains the needed DROP and CREATE statements for each view.

 - PaulPhillips_FinalProject_RDBM
	This file contains all of the official documentation for this database project.
	It provides both context to the actual problem, as well as insight as to how 
	each stage in database design was conducted. Additional notes and summaries are
	included as well.

 - FinalProject_AnalystApp
	This file contains a sample of R code in which could be used as means of
	creating answers for business questions. This code also illustrates how
	an analyst may connect and use the database from R.

 - farmers_markets_from_usda
	This csv file contains the original raw USDA Farmer's Market data used in the 
	project.

 - wiki_county_info
	This csv file contains to original raw Wikipedia demographic data for the regions
	associated in the raw USDA Farmer's Market data.

 - FarmerMarket_RDBS_3NF
	This csv file contains the data in its final format prior to being entered into the
	database. Each 'sheet' represents how the data is to be placed into each of the tables
	inside the actual database. 

 - IST659+Project+Description
	pdf file containing project framework requirements and overview of expectations.

 - 