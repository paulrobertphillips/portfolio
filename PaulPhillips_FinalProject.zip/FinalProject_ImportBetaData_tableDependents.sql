/* 
	Author: Paul R Phillips
	Course: IST659 M400
	Date: 12/13/2020

	File: Data Creation

	Description:
		This file contains all the code needed to import beta data 
		into the database tables with FK's. 

	Developer Notes:
		 Data was inserted into the tables following the same order
		 in which the tables were created.
*/

/* Begin: Non-associative tables with FK's*/
-- Insert values into pjt.Media
INSERT INTO pjt.Media (WebsiteURL, FaceBook, Twitter, YouTube, MarketID) 
VALUES 
('https://www.portlandfarmersmarket.org/','https://www.facebook.com/portlandfarmersmarket/', 'https://twitter.com/portlandfarmers?lang=en', NULL, 1)
GO
INSERT INTO pjt.Media (WebsiteURL, FaceBook, Twitter, YouTube, MarketID) 
VALUES
('http://millcityfarmersmarket.org/','https://www.facebook.com/MillCityFarmersMarket/','https://twitter.com/mcfarmersmkt',NULL,2)
GO
INSERT INTO pjt.Media (WebsiteURL, FaceBook, Twitter, YouTube, MarketID) 
VALUES
('http://www.cityofrochester.gov/publicmarket','www.facebook.com/cityofrochesterpublicmarket',NULL,NULL,3)
GO
INSERT INTO pjt.Media (WebsiteURL, FaceBook, Twitter, YouTube, MarketID) 
VALUES
('http://www.andersonville.org','https://www.facebook.com/andersonville?ref=bookmarks',NULL,NULL,4)
GO
INSERT INTO pjt.Media (WebsiteURL, FaceBook, Twitter, YouTube, MarketID) 
VALUES
('http://greencitymarket.org/','https://www.facebook.com/greencitymarket','https://twitter.com/GreenCityMarket',NULL,5)
GO
INSERT INTO pjt.Media (WebsiteURL, FaceBook, Twitter, YouTube, MarketID) 
VALUES
('http://www.logansquarefarmersmarket.org','www.facebook.com/LoganSquareFarmersMarket','www.twitter.com/LSFarmersMarket',NULL,6)
GO
INSERT INTO pjt.Media (WebsiteURL, FaceBook, Twitter, YouTube, MarketID) 
VALUES
('http://www.unionsquaremain.org','https://www.facebook.com/unionsquaremarkets/','https://twitter.com/unionsquarefm',NULL,7)
GO
INSERT INTO pjt.Media (WebsiteURL, FaceBook, Twitter, YouTube, MarketID) 
VALUES
('http://www.downtoearthmarkets.com','https://www.facebook.com/parkslopefarmersmarket/','https://twitter.com/DowntoEarthMkts',NULL,8)
GO
INSERT INTO pjt.Media (WebsiteURL, FaceBook, Twitter, YouTube, MarketID) 
VALUES
('http://www.bensidounmidwestmarkets.com/','facebook.com/BensenvilleFrenchMarket','https://twitter.com/BensidounMarket',NULL,9)
GO
INSERT INTO pjt.Media (WebsiteURL, FaceBook, Twitter, YouTube, MarketID) 
VALUES
('http://www.bensidounmidwestmarkets.com/','facebook.com/GenevaFrenchMarket','https://twitter.com/BensidounMarket',NULL,10)
GO

-- Insert values into pjt.MarketInfoUpdate
INSERT INTO pjt.MarketInfoUpdate (updateTime, MarketID)
VALUES
	('2018-07-27 12:12:00',1)
	,('2018-07-26 15:52:00',2)
	,('2017-06-20 14:35:00',3)
	,('2019-04-10 14:31:00',4)
	,('2016-02-04 18:23:00',5)
	,('2014-08-05 14:25:00',6)
	,('2019-05-23 11:00:00',7)
	,('2018-10-01 10:00:00',8)
	,('2016-07-16 17:11:00',9)
	,('2016-07-18 14:43:00',10)

-- Insert values into pjt.Coordinate
INSERT INTO pjt.Coordinate (Longitude, Latitude, MarketID)
VALUES
	(-122.68509,45.512409,1)
	,(-93.256279,44.97821,2)
	,(-77.589745,43.1656,3)
	,(-87.668701,41.978001,4)
	,(-87.634109,41.915276,5)
	,(-87.704971,41.928249,6)
	,(-71.094536,42.379761,7)
	,(-73.983925,40.672276,8)
	,(-87.941925,41.956081,9)
	,(-88.311218,41.883766,10)

/* End: Non-associative tables with FK's*/

/* Begin: Associative tables with FK's*/

-- Insert values into pjt.MarketPayment
INSERT INTO pjt.MarketPayment (MarketID, PaymentID)
VALUES
	(1, 1)
	,(2, 2)
	,(3, 2)
	,(4, 4)
	,(5, 3)
	,(6, 4)
	,(7, 5)
	,(8, 3)
	,(9, 1)
	,(10, 2)

-- Insert values into pjt.MarketProductSorce
INSERT INTO pjt.MarketProductSource(MarketID, ProductSourceID)
VALUES
	(1, 2)
	,(2, 2)
	,(3, 3)
	,(4, 1)
	,(5, 3)
	,(6, 1)
	,(7, 1)
	,(8, 2)
	,(9, 1)
	,(10, 3)

-- Insert values into pjt.MarketVegetarianProduct
INSERT INTO pjt.MarketVegetarianProduct(MarketID, VegetarianProductID)
VALUES
	(1, 7)
	,(2, 7)
	,(3, 2)
	,(4, 3)
	,(5, 4)
	,(6, 5)
	,(7, 2)
	,(8, 1)
	,(9, 1)
	,(10, 5)

-- Insert values into pjt.MarketAnimalProduct
INSERT INTO pjt.MarketAnimalProduct(MarketID, AnimalProductID)
VALUES
	(1, 1)
	,(2, 2)
	,(3, 2)
	,(4, 2)
	,(5, 1)
	,(6, 1)
	,(7, 2)
	,(8, 1)
	,(9, 2)
	,(10, 1)

-- Insert values into pjt.MarketMeat
-- Try using:
INSERT INTO pjt.MarketMeat(MarketID, MeatID)
VALUES
	(1, 2)
	,(2, 3)
	,(3, 1)
	,(4, 1)
	,(5, 2)
	,(6, 1)
	,(7, 3)
	,(8, 3)
	,(9, 1)
	,(10, 2)

-- Insert values into pjt.MarketBeverage
INSERT INTO pjt.MarketBeverage(MarketID, BeverageID)
VALUES
	(1, 2)
	,(2, 3)
	,(3, 1)
	,(4, 3)
	,(5, 3)
	,(6, 1)
	,(7, 3)
	,(8, 1)
	,(9, 2)
	,(10, 1)

-- Insert values into pjt.MarketCondiment
INSERT INTO pjt.MarketCondiment(MarketID, CondimentID)
VALUES
	(1, 1)
	,(2, 4)
	,(3, 3)
	,(4, 2)
	,(5, 1)
	,(6, 2)
	,(7, 4)
	,(8, 3)
	,(9, 1)
	,(10, 4)

-- Insert values into pjt.MarketMiscProduct
INSERT INTO pjt.MarketMiscProduct(MarketID, MiscProductID)
VALUES
	(1, 8)
	,(2, 8)
	,(3, 6)
	,(4, 3)
	,(5, 1)
	,(6, 1)
	,(7, 4)
	,(8, 7)
	,(9, 1)
	,(10, 2)

-- Insert values into pjt.MarketDemographic
INSERT INTO pjt.MarketDemographic(MarketID, DemographicID)
VALUES
	(1, 1)
	,(2, 2)
	,(3, 3)
	,(4, 4)
	,(5, 4)
	,(6, 4)
	,(7, 5)
	,(8, 6)
	,(9, 7)
	,(10, 7)

-- Insert values into pjt.MarketCity
INSERT INTO pjt.MarketCity(MarketID, CityID)
VALUES
	(1, 1)
	,(2, 2)
	,(3, 3)
	,(4, 4)
	,(5, 4)
	,(6, 4)
	,(7, 5)
	,(8, 6)
	,(9, 7)
	,(10, 8)

-- Insert values into pjt.MarketCounty
INSERT INTO pjt.MarketCounty(MarketID, CountyID)
VALUES
	(1, 1)
	,(2, 2)
	,(3, 3)
	,(4, 4)
	,(5, 4)
	,(6, 4)
	,(7, 5)
	,(8, 6)
	,(9, 7)
	,(10, 7)

-- Insert values into pjt.MarketState
INSERT INTO pjt.MarketState(MarketID, AddressStateID)
VALUES
	(1, 1)
	,(2, 2)
	,(3, 3)
	,(4, 4)
	,(5, 4)
	,(6, 4)
	,(7, 5)
	,(8, 3)
	,(9, 4)
	,(10, 4)

-- Insert values into pjt.MarketPostalCode
INSERT INTO pjt.MarketPostalCode(MarketID, PostalCodeID)
VALUES
	(1, 1)
	,(2, 2)
	,(3, 3)
	,(4, 4)
	,(5, 5)
	,(6, 6)
	,(7, 7)
	,(8, 8)
	,(9, 9)
	,(10, 10)

/* End: Associative tables with FK's*/

