/* 
	Author: Paul R Phillips
	Course: IST659 M400
	Date: 12/13/2020

	File: Fail Safe (Clear Tables of Beta Data)

	Description:
		This file contains all the code needed to physically empty all the tables
		incase major structural updates are needed

	Warning:
		This file will delete all data from every table. Only run file if all
		data from every table needs to be removed. Again this file should only
		be executed in cases where all data needs to be removed in order to 
		make stuctural updates to tables.
*/

DELETE pjt.MarketPayment
DELETE pjt.MarketProductSource
DELETE pjt.MarketVegetarianProduct
DELETE pjt.MarketAnimalProduct
DELETE pjt.MarketMeat
DELETE pjt.MarketBeverage
DELETE pjt.MarketCondiment
DELETE pjt.MarketMiscProduct
DELETE pjt.MarketDemographic
DELETE pjt.MarketCity
DELETE pjt.MarketCounty
DELETE pjt.MarketState
DELETE pjt.MarketPostalCode
DELETE pjt.Payment
DELETE pjt.ProductSource
DELETE pjt.VegetarianProduct
DELETE pjt.AnimalProduct
DELETE pjt.Meat
DELETE pjt.Beverage
DELETE pjt.Condiment
DELETE pjt.MiscProduct
DELETE pjt.Demographic
DELETE pjt.City
DELETE pjt.County
DELETE pjt.AddressState
DELETE pjt.PostalCode
DELETE pjt.MarketInfoUpdate
DELETE pjt.Media
DELETE pjt.Coordinate
DELETE pjt.Market