/* 
	Author: Paul R Phillips
	Course: IST659 M400
	Date: 12/13/2020

	File: Database Stored Procedures

	Description:
		This file contains all the necessary stored procedures
		which users can use to make proper updates to the database.
	
	Note: 
		The add stored producers are designed to be used as means to
		adding market details for new markets as well as already existing.
		Source tables (such as recorded "Payment Types") are implicitly
		upated if needed along side the relevant associative table.
		User must provide new value for market detail along with the 
		market's FMID number. (FMID is not the primary key for Market table
		it is the registered market number with the USDA).
*/

-- Update Market Street Address, Season Dates, or Operating Hours
DROP PROCEDURE pjt.UpdateMarketInfo
GO

CREATE PROCEDURE pjt.UpdateMarketInfo
	@FMID int = NULL
	, @MarketName varchar(200) = NULL
	, @StreetAddress varchar(200) = NULL
	, @SeasonStartDate date = NULL
	, @SeasonEndDate date = NULL
	, @MarketDay varchar(3) = NULL
	, @BusinessOpen time = NULL
	, @BusinessClose time = NULL
AS
BEGIN
	-- Make provided updates so long as NULL has not been passed
	-- Update street address
	IF @MarketName IS NOT NULL
		UPDATE pjt.Market SET MarketName = @MarketName
		WHERE FMID = @FMID

	IF @StreetAddress IS NOT NULL
		UPDATE pjt.Market SET StreetAddress = @StreetAddress
		WHERE FMID = @FMID

	-- Update season start
	IF @SeasonStartDate IS NOT NULL
		UPDATE pjt.Market SET SeasonStartDate = @SeasonStartDate
		WHERE FMID = @FMID

	-- Update season end
	IF @SeasonEndDate IS NOT NULL
		UPDATE pjt.Market SET SeasonEndDate = @SeasonEndDate
		WHERE FMID = @FMID
	
	-- Update market day
	IF @MarketDay IS NOT NULL
		UPDATE pjt.Market SET MarketDay = @MarketDay
		WHERE FMID = @FMID

	-- Update business open hours
	IF @BusinessOpen IS NOT NULL
		UPDATE pjt.Market SET BusinessOpen = @BusinessOpen
		WHERE FMID = @FMID

	-- Update business close hours
	IF @BusinessClose IS NOT NULL
		UPDATE pjt.Market SET BusinessClose = @BusinessClose
		WHERE FMID = @FMID

	-- Update "last updated" value for given market
	UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
	WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)

END
GO

-----------------------------------------------------------------------------------------------------------------------------------------

DROP PROCEDURE pjt.AddMarketPaymentType
GO 

-- Stored Procedure for adding new market payment sources for a given market
CREATE PROCEDURE pjt.AddMarketPaymentType(@AcceptedPayForm varchar(20), @FMID int) AS
BEGIN
	-- See if payment table needs to be updated 
	-- Note: Unique constraint will prevent payment types, or available payment types for individual markets to be entered more than once
	BEGIN TRY
		INSERT INTO pjt.Payment(AcceptedPayForm) VALUES (@AcceptedPayForm)

		INSERT INTO pjt.MarketPayment(PaymentID, MarketID) VALUES ((SELECT pjt.Payment.PaymentID FROM pjt.Payment WHERE pjt.Payment.AcceptedPayForm = @AcceptedPayForm)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END TRY
	-- If not just update associative table
	BEGIN CATCH
		INSERT INTO pjt.MarketPayment(PaymentID, MarketID) VALUES ((SELECT pjt.Payment.PaymentID FROM pjt.Payment WHERE pjt.Payment.AcceptedPayForm = @AcceptedPayForm)
															,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END CATCH
END
GO

-----------------------------------------------------------------------------------------------------------------------------------------

DROP PROCEDURE pjt.AddMarketProductSource
GO 

-- Stored Procedure for adding new market payment sources for a given market
CREATE PROCEDURE pjt.AddMarketProductSource(@ProductSource varchar(50), @FMID int) AS
BEGIN
	-- See if payment table needs to be updated 
	-- Note: Unique constraint will prevent payment types, or available payment types for individual markets to be entered more than once
	BEGIN TRY
		INSERT INTO pjt.ProductSource(ProductSource) VALUES (@ProductSource)

		INSERT INTO pjt.MarketProductSource(ProductSourceID, MarketID) VALUES ((SELECT pjt.ProductSource.ProductSourceID FROM pjt.ProductSource WHERE pjt.ProductSource.ProductSource = @ProductSource)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END TRY
	-- If not just update associative table
	BEGIN CATCH
		INSERT INTO pjt.MarketProductSource(ProductSourceID, MarketID) VALUES ((SELECT pjt.ProductSource.ProductSourceID FROM pjt.ProductSource WHERE pjt.ProductSource.ProductSource = @ProductSource)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END CATCH
END
GO

-----------------------------------------------------------------------------------------------------------------------------------------
DROP PROCEDURE pjt.AddMarketVegetarianProduct
GO 

-- Stored Procedure for adding new market payment sources for a given market
CREATE PROCEDURE pjt.AddMarketVegetarianProduct(@VegetarianProduce varchar(50), @FMID int) AS
BEGIN
	-- See if payment table needs to be updated 
	-- Note: Unique constraint will prevent payment types, or available payment types for individual markets to be entered more than once
	BEGIN TRY
		INSERT INTO pjt.VegetarianProduct(VegetarianProduce) VALUES (@VegetarianProduce)

		INSERT INTO pjt.MarketVegetarianProduct(VegetarianProductID, MarketID) VALUES ((SELECT pjt.VegetarianProduct.VegetarianProductID FROM pjt.VegetarianProduct WHERE pjt.VegetarianProduct.VegetarianProduce = @VegetarianProduce)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END TRY
	-- If not just update associative table
	BEGIN CATCH
		INSERT INTO pjt.MarketVegetarianProduct(VegetarianProductID, MarketID) VALUES ((SELECT pjt.VegetarianProduct.VegetarianProductID FROM pjt.VegetarianProduct WHERE pjt.VegetarianProduct.VegetarianProduce = @VegetarianProduce)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END CATCH
END
GO

-----------------------------------------------------------------------------------------------------------------------------------------

DROP PROCEDURE pjt.AddMarketAnimalProduct
GO 

-- Stored Procedure for adding new market payment sources for a given market
CREATE PROCEDURE pjt.AddMarketAnimalProduct(@AnimalProduct varchar(50), @FMID int) AS
BEGIN
	-- See if payment table needs to be updated 
	-- Note: Unique constraint will prevent payment types, or available payment types for individual markets to be entered more than once
	BEGIN TRY
		INSERT INTO pjt.AnimalProduct(AnimalProduct) VALUES (@AnimalProduct)

		INSERT INTO pjt.MarketAnimalProduct(AnimalProductID, MarketID) VALUES ((SELECT pjt.AnimalProduct.AnimalProductID FROM pjt.AnimalProduct WHERE pjt.AnimalProduct.AnimalProduct = @AnimalProduct)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END TRY
	-- If not just update associative table
	BEGIN CATCH
		INSERT INTO pjt.MarketAnimalProduct(AnimalProductID, MarketID) VALUES ((SELECT pjt.AnimalProduct.AnimalProductID FROM pjt.AnimalProduct WHERE pjt.AnimalProduct.AnimalProduct = @AnimalProduct)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END CATCH
END
GO

-----------------------------------------------------------------------------------------------------------------------------------------

DROP PROCEDURE pjt.AddMarketMeat
GO 

-- Stored Procedure for adding new market payment sources for a given market
CREATE PROCEDURE pjt.AddMarketMeat(@Meat varchar(50), @FMID int) AS
BEGIN
	-- See if payment table needs to be updated 
	-- Note: Unique constraint will prevent payment types, or available payment types for individual markets to be entered more than once
	BEGIN TRY
		INSERT INTO pjt.Meat(Meats) VALUES (@Meat)

		INSERT INTO pjt.MarketMeat(MeatID, MarketID) VALUES ((SELECT pjt.Meat.MeatID FROM pjt.Meat WHERE pjt.Meat.Meats = @Meat)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END TRY
	-- If not just update associative table
	BEGIN CATCH
		INSERT INTO pjt.MarketMeat(MeatID, MarketID) VALUES ((SELECT pjt.Meat.MeatID FROM pjt.Meat WHERE pjt.Meat.Meats = @Meat)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END CATCH
END
GO

-----------------------------------------------------------------------------------------------------------------------------------------

DROP PROCEDURE pjt.AddMarketBeverage
GO 

-- Stored Procedure for adding new market payment sources for a given market
CREATE PROCEDURE pjt.AddMarketBeverage(@Beverage varchar(50), @FMID int) AS
BEGIN
	-- See if payment table needs to be updated 
	-- Note: Unique constraint will prevent payment types, or available payment types for individual markets to be entered more than once
	BEGIN TRY
		INSERT INTO pjt.Beverage(Beverages) VALUES (@Beverage)

		INSERT INTO pjt.MarketBeverage(BeverageID, MarketID) VALUES ((SELECT pjt.Beverage.BeverageID FROM pjt.Beverage WHERE pjt.Beverage.Beverages = @Beverage)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END TRY
	-- If not just update associative table
	BEGIN CATCH
		INSERT INTO pjt.MarketBeverage(BeverageID, MarketID) VALUES ((SELECT pjt.Beverage.BeverageID FROM pjt.Beverage WHERE pjt.Beverage.Beverages = @Beverage)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END CATCH
END
GO

-----------------------------------------------------------------------------------------------------------------------------------------

DROP PROCEDURE pjt.AddMarketCondiment
GO 

-- Stored Procedure for adding new market payment sources for a given market
CREATE PROCEDURE pjt.AddMarketCondiment(@Condiment varchar(50), @FMID int) AS
BEGIN
	-- See if payment table needs to be updated 
	-- Note: Unique constraint will prevent payment types, or available payment types for individual markets to be entered more than once
	BEGIN TRY
		INSERT INTO pjt.Condiment(Condiments) VALUES (@Condiment)

		INSERT INTO pjt.MarketCondiment(CondimentID, MarketID) VALUES ((SELECT pjt.Condiment.CondimentID FROM pjt.Condiment WHERE pjt.Condiment.Condiments = @Condiment)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END TRY
	-- If not just update associative table
	BEGIN CATCH
		INSERT INTO pjt.MarketCondiment(CondimentID, MarketID) VALUES ((SELECT pjt.Condiment.CondimentID FROM pjt.Condiment WHERE pjt.Condiment.Condiments = @Condiment)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END CATCH
END
GO

-----------------------------------------------------------------------------------------------------------------------------------------

DROP PROCEDURE pjt.AddMarketMiscProduct
GO 

-- Stored Procedure for adding new market payment sources for a given market
CREATE PROCEDURE pjt.AddMarketMiscProduct(@MiscProduct varchar(50), @FMID int) AS
BEGIN
	-- See if payment table needs to be updated 
	-- Note: Unique constraint will prevent payment types, or available payment types for individual markets to be entered more than once
	BEGIN TRY
		INSERT INTO pjt.MiscProduct(MiscProducts) VALUES (@MiscProduct)

		INSERT INTO pjt.MarketMiscProduct(MiscProductID, MarketID) VALUES ((SELECT pjt.MiscProduct.MiscProductID FROM pjt.MiscProduct WHERE pjt.MiscProduct.MiscProducts = @MiscProduct)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END TRY
	-- If not just update associative table
	BEGIN CATCH
		INSERT INTO pjt.MarketMiscProduct(MiscProductID, MarketID) VALUES ((SELECT pjt.MiscProduct.MiscProductID FROM pjt.MiscProduct WHERE pjt.MiscProduct.MiscProducts = @MiscProduct)
																	,(SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END CATCH
END
GO

-----------------------------------------------------------------------------------------------------------------------------------------

DROP PROCEDURE pjt.AddMarketMedia
GO 

-- Stored Procedure for adding new market payment sources for a given market
CREATE PROCEDURE pjt.AddMarketMedia(
	@FMID int
	, @WebsiteURL varchar(200) = NULL
	, @FaceBook varchar(200) = NULL
	, @Twitter varchar(200) = NULL
	, @YouTube varchar(200) = NULL
) 
AS
BEGIN
	-- Insert provided website url
	-- If there is already an existing row for the given FMID, simply update the entry so long as it's not NULL
	IF NOT EXISTS(SELECT 1 FROM pjt.Media WHERE pjt.Media.MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID))
	BEGIN
		INSERT INTO pjt.Media(WebsiteURL, FaceBook, Twitter, YouTube, MarketID)
		VALUES(
			@WebsiteURL
			, @FaceBook
			, @Twitter
			, @YouTube
			, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
		)
		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END

	ELSE
	BEGIN
		IF @WebsiteURL IS NOT NULL
			UPDATE pjt.Media SET WebsiteURL = @WebsiteURL
			WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)

		IF @FaceBook IS NOT NULL
			UPDATE pjt.Media SET FaceBook = @FaceBook
			WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
			
		IF @Twitter IS NOT NULL
			UPDATE pjt.Media SET Twitter = @Twitter
			WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)

		IF @YouTube IS NOT NULL
			UPDATE pjt.Media SET YouTube = @YouTube
			WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)

		-- Update "last updated" value for given market
		UPDATE pjt.MarketInfoUpdate SET updateTime = GETDATE()
		WHERE MarketID = (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	END
END
GO

-----------------------------------------------------------------------------------------------------------------------------------------
DROP PROCEDURE pjt.AddNewMarket
GO 

-- Stored Procedure for adding new market payment sources for a given market
CREATE PROCEDURE pjt.AddNewMarket(
	@FMID int
	, @MarketName varchar(250)
	, @StreetAddress varchar(250)
	, @City varchar(50)
	, @County varchar(50)
	, @AddressState varchar(50)
	, @PostalCode varchar(10)
	, @Longitude decimal(13,10)
	, @Latitude decimal(13,10)
	, @SeasonStartDate date
	, @SeasonEndDate date
	, @MarketDay varchar(3)
	, @BusinessOpen time
	, @BusinessClose time
) 
AS
BEGIN
	-- Insert provided website url
	-- If there is already an existing row for the given FMID, simply update the entry so long as it's not NULL
	IF NOT EXISTS(SELECT 1 FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	BEGIN
		INSERT INTO pjt.Market(FMID
							   , MarketName
							   , StreetAddress
							   , SeasonStartDate
							   , SeasonEndDate
							   , MarketDay
							   , BusinessOpen
							   , BusinessClose
		)
		VALUES(
			@FMID
			, @MarketName
			, @StreetAddress
			, @SeasonStartDate
			, @SeasonEndDate
			, @MarketDay
			, @BusinessOpen
			, @BusinessClose
		)
		-- Create "last updated" entry for new market
		INSERT INTO pjt.MarketInfoUpdate(updateTime, MarketID) 
		VALUES (
			GETDATE()
			, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
		)
	END

	-- If the city doesn't already exist, insert it
	BEGIN TRY
		INSERT INTO pjt.City(City) VALUES (@City)

		INSERT INTO pjt.MarketCity(CityID, MarketID)
		VALUES(
			(SELECT pjt.City.CityID FROM pjt.City WHERE pjt.City.City = @City)
			, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
		)
	END TRY
	-- If not just update associative table
	BEGIN CATCH
		INSERT INTO pjt.MarketCity(CityID, MarketID)
		VALUES(
			(SELECT pjt.City.CityID FROM pjt.City WHERE pjt.City.City = @City)
			, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
		)
	END CATCH

	-- If the county doesn't already exist, insert it
	BEGIN TRY
		INSERT INTO pjt.County(County) VALUES (@County)

		INSERT INTO pjt.MarketCounty(CountyID, MarketID)
		VALUES(
			(SELECT pjt.County.CountyID FROM pjt.County WHERE pjt.County.County = @County)
			, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
		)
	END TRY
	-- If not just update associative table
	BEGIN CATCH
		INSERT INTO pjt.MarketCounty(CountyID, MarketID)
		VALUES(
			(SELECT pjt.County.CountyID FROM pjt.County WHERE pjt.County.County = @County)
			, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
		)
	END CATCH

	-- If the state doesn't already exist, insert it
	BEGIN TRY
		INSERT INTO pjt.AddressState(AddressState) VALUES (@AddressState)

		INSERT INTO pjt.MarketState(AddressStateID, MarketID)
		VALUES(
			(SELECT pjt.AddressState.AddressStateID FROM pjt.AddressState WHERE pjt.AddressState.AddressState = @AddressState)
			, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
		)
	END TRY
	-- If not just update associative table
	BEGIN CATCH
		INSERT INTO pjt.MarketState(AddressStateID, MarketID)
		VALUES(
			(SELECT pjt.AddressState.AddressStateID FROM pjt.AddressState WHERE pjt.AddressState.AddressState = @AddressState)
			, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
		)
	END CATCH

	-- If the postal code doesn't already exist, insert it
	BEGIN TRY
		INSERT INTO pjt.PostalCode(PostalCode) VALUES (@PostalCode)

		INSERT INTO pjt.MarketPostalCode(PostalCodeID, MarketID)
		VALUES(
			(SELECT pjt.PostalCode.PostalCodeID FROM pjt.PostalCode WHERE pjt.PostalCode.PostalCode = @PostalCode)
			, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
		)
	END TRY
	-- If not just update associative table
	BEGIN CATCH
		INSERT INTO pjt.MarketPostalCode(PostalCodeID, MarketID)
		VALUES(
			(SELECT pjt.PostalCode.PostalCodeID FROM pjt.PostalCode WHERE pjt.PostalCode.PostalCode = @PostalCode)
			, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
		)
	END CATCH

	--Update longitude & latitude table 
	INSERT INTO pjt.Coordinate(Longitude, Latitude, MarketID)
	VALUES(
		@Longitude
		, @Latitude
		, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
	)
	
END
GO

-----------------------------------------------------------------------------------------------------------------------------------------

-- Add new market area demographic information
-- All metrics must be entered for area, NULL not accepted 
DROP PROCEDURE pjt.AddMarketAreaDemographics
GO

CREATE PROCEDURE pjt.AddMarketAreaDemographics(
	@FMID int
	, @County varchar(50)
	, @AddressState varchar(50)
	, @PerCapita int
	, @MedianHouseholdIncome int
	, @MedianFamilyIncome int 
	, @AreaPopulation int 
	, @NumberOfHouseholds int 
)
AS
BEGIN
	-- Ensure inserted county and statee already exists, otherwise don't commit change
	DECLARE @CountyExists int, @AddressStateExists int
	SET @CountyExists=(SELECT 1 FROM pjt.County WHERE pjt.County.County = @County) 
	SET @AddressStateExists=(SELECT 1 FROM pjt.AddressState WHERE pjt.AddressState.AddressState = @AddressState)

	IF @CountyExists = 1 AND @AddressStateExists = 1
	BEGIN
		BEGIN TRY
			-- Try to add demographics for associated area, if not just update associative table
			-- There is a unique constraint on combination of all demographic metrics (i.e. no two
			-- counties can have exactly the same entries for all columns)
			INSERT INTO pjt.Demographic(
				PerCapita
				, MedianHouseholdIncome
				, MedianFamilyIncome
				, AreaPopulation
				, NumberOfHouseholds
			)
			VALUES(
				@PerCapita
				, @MedianHouseholdIncome
				, @MedianFamilyIncome 
				, @AreaPopulation 
				, @NumberOfHouseholds
			)

			-- Enter values for associative table
			INSERT INTO pjt.MarketDemographic(DemographicID, MarketID)
			VALUES(
				(SELECT pjt.Demographic.DemographicID FROM pjt.Demographic 
					WHERE pjt.Demographic.PerCapita = @PerCapita 
						AND pjt.Demographic.MedianHouseholdIncome = @MedianHouseholdIncome
						AND pjt.Demographic.MedianFamilyIncome = @MedianFamilyIncome
						AND pjt.Demographic.AreaPopulation = @AreaPopulation
						AND pjt.Demographic.NumberOfHouseholds = @NumberOfHouseholds
				)
				, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
			)

			-- Create "last updated" entry for new market
			INSERT INTO pjt.MarketInfoUpdate(updateTime, MarketID) 
			VALUES (
				GETDATE()
				, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
			)
		END TRY

		BEGIN CATCH
			-- If provided county, state demographics already exist in database simply include 
			-- market demographic reference in associative table
			INSERT INTO pjt.MarketDemographic(DemographicID, MarketID)
			VALUES(
				(SELECT pjt.Demographic.DemographicID FROM pjt.Demographic 
					WHERE pjt.Demographic.PerCapita = @PerCapita 
						AND pjt.Demographic.MedianHouseholdIncome = @MedianHouseholdIncome
						AND pjt.Demographic.MedianFamilyIncome = @MedianFamilyIncome
						AND pjt.Demographic.AreaPopulation = @AreaPopulation
						AND pjt.Demographic.NumberOfHouseholds = @NumberOfHouseholds
				)
				, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
			)

			-- Create "last updated" entry for new market
			INSERT INTO pjt.MarketInfoUpdate(updateTime, MarketID) 
			VALUES (
				GETDATE()
				, (SELECT pjt.Market.MarketID FROM pjt.Market WHERE pjt.Market.FMID = @FMID)
			)
		END CATCH
	END

	ELSE
	BEGIN
		SELECT 'Please provide appropriate County and State for given Market'
	END
END
GO

/* Left to do:
	- Insert new area demographics
	- Add Market demographics (make connection to area demographics based on associated city
*/

-- Then just connect applications!

-----------------------------------------------------------------------------------------------------------------------------------------

