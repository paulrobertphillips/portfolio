/* 
	Author: Paul R Phillips
	Course: IST659 M400
	Date: 12/13/2020

	File: Data Creation

	Description:
		This file contains all the code needed to import beta data 
		into the database tables with no FK's. 

	Developer Notes:
		 Data was inserted into the tables following the same order
		 in which the tables were created. Data for associative tables
		 will be inserted using a separate file.
*/

-- Insert values into pjt.Payment
INSERT INTO pjt.Payment (AcceptedPayForm) 
VALUES 
	('Credit')
	,('WIC')
	,('WICcash')
	,('SFMNP')
	,('SNAP')
GO
-- Insert values into pjt.ProductSource
INSERT INTO pjt.ProductSource (ProductSource)
VALUES
	('Organic')
	,('Prepared')
	,('WildHarvested')
GO
-- Insert values into pjt.VegetarianProduct
INSERT INTO pjt.VegetarianProduct(VegetarianProduce)
VALUES
	('Tofu')
	,('Mushrooms')
	,('Grains')
	,('Beans')
	,('Nuts')
	,('Vegetables')
	,('Fruits')
GO
-- Insert values into pjt.AnimalProduct
INSERT INTO pjt.AnimalProduct(AnimalProduct)
VALUES
	('Eggs')
	,('Cheese')
GO
-- Insert values into pjt.Meat
INSERT INTO pjt.Meat(Meats)
VALUES
	('Seafood')
	,('Meat')
	,('Poultry')
GO

-- Insert values into pjt.Beverage
INSERT INTO pjt.Beverage(Beverages)
VALUES
	('Juices')
	,('Coffee')
	,('Wine')
GO
-- Insert values into pjt.Condiment
INSERT INTO pjt.Condiment(Condiments)
VALUES
	('Herbs')
	,('Honey')
	,('Jams')
	,('Maple')
GO
-- Insert values into pjt.MiscProducts
INSERT INTO pjt.MiscProduct(MiscProducts)
VALUES
	('Flowers')
	,('PetFood')
	,('Crafts')
	,('Soap')
	,('Bakedgoods')
	,('Nursery')
	,('Plants')
	,('Trees')
GO

-- Insert values into pjt.Demographic
INSERT INTO pjt.Demographic(PerCapita, MedianHouseholdIncome, MedianFamilyIncome, NumberOfHouseholds, AreaPopulation)
VALUES
(30475,52511,65897,305939,747641)
GO
INSERT INTO pjt.Demographic(PerCapita, MedianHouseholdIncome, MedianFamilyIncome, NumberOfHouseholds, AreaPopulation)
VALUES
(37485,64403,84559,481263,1170623)
GO
INSERT INTO pjt.Demographic(PerCapita, MedianHouseholdIncome, MedianFamilyIncome, NumberOfHouseholds, AreaPopulation)
VALUES
(28732,52394,68524,297040,746548)
GO
INSERT INTO pjt.Demographic(PerCapita, MedianHouseholdIncome, MedianFamilyIncome, NumberOfHouseholds, AreaPopulation)
VALUES
(30183,54548,66187,1933335,5212372)
GO
INSERT INTO pjt.Demographic(PerCapita, MedianHouseholdIncome, MedianFamilyIncome, NumberOfHouseholds, AreaPopulation)
VALUES
(42861,82090,104032,581120,1522533)
GO
INSERT INTO pjt.Demographic(PerCapita, MedianHouseholdIncome, MedianFamilyIncome, NumberOfHouseholds, AreaPopulation)
VALUES
(25289,46085,51581,916025,2539789)
GO
INSERT INTO pjt.Demographic(PerCapita, MedianHouseholdIncome, MedianFamilyIncome, NumberOfHouseholds, AreaPopulation)
VALUES
(38570,78487,95208,336028,922803)
GO
INSERT INTO pjt.Demographic(PerCapita, MedianHouseholdIncome, MedianFamilyIncome, NumberOfHouseholds, AreaPopulation)
VALUES
(32887,57952,68840,20530,51479)
GO
INSERT INTO pjt.Demographic(PerCapita, MedianHouseholdIncome, MedianFamilyIncome, NumberOfHouseholds, AreaPopulation)
VALUES
(27256,53596,63910,1411727,3889161)
GO
INSERT INTO pjt.Demographic(PerCapita, MedianHouseholdIncome, MedianFamilyIncome, NumberOfHouseholds, AreaPopulation)
VALUES
(35763,72112,88618,545071,1535248)
GO

-- Insert values into pjt.City
INSERT INTO pjt.City (City)
VALUES
	('Portland')
	,('Minneapolis')
	,('Rochester')
	,('Chicago')
	,('Somerville')
	,('Brooklyn')
	,('Bensenville')
	,('Geneva')
	,('Lisle')
	,('Villa Park')

-- Insert values into pjt.County
INSERT INTO pjt.County (County)
VALUES
	('Multnomah')
	,('Hennepin')
	,('Monroe')
	,('Cook')
	,('Middlesex')
	,('Kings')
	,('DuPage')
	,('Worcester')
	,('Maricopa')
	,('Alameda')

-- Insert values into pjt.State
INSERT INTO pjt.AddressState (AddressState)
VALUES
	('Oregon')
	,('Minnesota')
	,('New York')
	,('Illinois')
	,('Massachusetts')
	,('Maryland')
	,('Arizona')
	,('California')
	,('Virginia')
	,('Florida')

-- Insert values into pjt.PostalCode
INSERT INTO pjt.PostalCode (PostalCode)
VALUES
	('97201')
	,('55401')
	,('14609')
	,('60640')
	,('02129')
	,('11201')
	,('60532')
	,('90201')
	,('20121')
	,('33144')


-- Insert values into pjt.Market
INSERT INTO pjt.Market(FMID, MarketName, StreetAddress, SeasonStartDate, SeasonEndDate, MarketDay, BusinessOpen, BusinessClose)
VALUES
(1018482,'Portland Farmers Market - Portland State University','SW Park and Montgomery','4/1/2018','10/1/2018','Sat','08:30:00','14:00:00')
GO
INSERT INTO pjt.Market(FMID, MarketName, StreetAddress, SeasonStartDate, SeasonEndDate, MarketDay, BusinessOpen, BusinessClose)
VALUES
(1012523,'Mill City Farmers Market, Inc.','704 South 2nd Street','5/5/2018','9/29/2018','Sat','08:00:00','13:00:00')
GO
INSERT INTO pjt.Market(FMID, MarketName, StreetAddress, SeasonStartDate, SeasonEndDate, MarketDay, BusinessOpen, BusinessClose)
VALUES
(1018182,'City of Rochester Public Market','280 North Union Street','1/1/2017','12/31/2017','Tue','06:00:00','18:00:00')
GO
INSERT INTO pjt.Market(FMID, MarketName, StreetAddress, SeasonStartDate, SeasonEndDate, MarketDay, BusinessOpen, BusinessClose)
VALUES
(1003516,'Andersonville Farmers Market','1500 W. Berwyn Ave.','5/8/2019','8/28/2019','Wed','15:00:00','20:00:00')
GO
INSERT INTO pjt.Market(FMID, MarketName, StreetAddress, SeasonStartDate, SeasonEndDate, MarketDay, BusinessOpen, BusinessClose)
VALUES
(1011774,'Green City Market - Outdoor','1817 N. Clark','5/7/2016','11/30/2016','Wed','07:00:00','13:00:00')
GO
INSERT INTO pjt.Market(FMID, MarketName, StreetAddress, SeasonStartDate, SeasonEndDate, MarketDay, BusinessOpen, BusinessClose)
VALUES
(1010423,'Logan Square Farmers Market','3100 W. Logan Boulevard','5/7/2015','10/22/2015','Sun','10:00:00','15:00:00')
GO
INSERT INTO pjt.Market(FMID, MarketName, StreetAddress, SeasonStartDate, SeasonEndDate, MarketDay, BusinessOpen, BusinessClose)
VALUES
(1019540,'Union Square Farmers Market','70 Union Square','5/18/2019','11/23/2019','Sat','09:00:00','13:00:00')
GO
INSERT INTO pjt.Market(FMID, MarketName, StreetAddress, SeasonStartDate, SeasonEndDate, MarketDay, BusinessOpen, BusinessClose)
VALUES
(1009895,'Down to Earth Park Slope Farmers Market','289 4th Street','1/1/2018','12/31/2018','Sun','10:00:00','16:00:00')
GO
INSERT INTO pjt.Market(FMID, MarketName, StreetAddress, SeasonStartDate, SeasonEndDate, MarketDay, BusinessOpen, BusinessClose)
VALUES
(1012679,'Bensenville French Market','10 S Center street','6/15/2016','8/31/2016','Wed','17:00:00','21:00:00')
GO
INSERT INTO pjt.Market(FMID, MarketName, StreetAddress, SeasonStartDate, SeasonEndDate, MarketDay, BusinessOpen, BusinessClose)
VALUES
(1012691,'Geneva French Market','Metra Parking Lot, NW Corner of South street & 4th Street.','4/17/2016','11/13/2016','Sun','09:00:00','14:00:00')
GO




