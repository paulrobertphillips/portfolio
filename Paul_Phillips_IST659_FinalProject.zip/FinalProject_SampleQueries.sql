/* 
	Author: Paul R Phillips
	Course: IST659 M400
	Date: 12/13/2020

	File: Sample Queries

	Description:
		This file contains all the code needed to answer the provided
		data questions used for this project. Aside from the utility
		queries listed directly below, all other queries are written
		on top of the created views for this database.
*/

/* Begin: Utility Queries */
-- The following queries are used to verify table relationships

-- Location Information for available markets
SELECT
	pjt.Market.MarketName AS MarketName
	,pjt.Market.StreetAddress AS StreetAddress
	,pjt.City.City AS City
	,pjt.County.County AS County
	,pjt.AddressState.AddressState AS MarketState
	,pjt.PostalCode.PostalCode AS PostalCode
	,pjt.Coordinate.Longitude AS Longitude
	,pjt.Coordinate.Latitude AS Latitude
FROM pjt.Market
JOIN pjt.MarketCity ON pjt.Market.MarketID = pjt.MarketCity.MarketID
JOIN pjt.MarketCounty ON pjt.Market.MarketID = pjt.MarketCounty.MarketID
JOIN pjt.MarketState ON pjt.Market.MarketID = pjt.MarketState.MarketID
JOIN pjt.MarketPostalCode ON pjt.Market.MarketID = pjt.MarketPostalCode.MarketID
LEFT JOIN pjt.City ON pjt.MarketCity.CityID = pjt.City.CityID
LEFT JOIN pjt.County ON pjt.MarketCounty.CountyID = pjt.County.CountyID
LEFT JOIN pjt.AddressState ON pjt.AddressState.AddressStateID = pjt.MarketState.AddressStateID
LEFT JOIN pjt.PostalCode ON pjt.PostalCode.PostalCodeID = pjt.MarketPostalCode.PostalCodeID
LEFT JOIN pjt.Coordinate ON pjt.Coordinate.MarketID = pjt.Market.MarketID
GO
-- All payment types, product sourcing, and products offered available markets
SELECT 
	pjt.Market.MarketName as MarketName
	,pjt.Payment.AcceptedPayForm as PayForm
	,pjt.ProductSource.ProductSource as ProductSource
	,pjt.VegetarianProduct.VegetarianProduce as Veggies
	,pjt.AnimalProduct.AnimalProduct as AnimalProduce
	,pjt.Meat.Meats as Meats
	,pjt.Beverage.Beverages as Beverages
	,pjt.Condiment.Condiments as Condiments
	,pjt.MiscProduct.MiscProducts as MiscProducts
FROM pjt.Market
JOIN pjt.MarketPayment ON pjt.Market.MarketID = pjt.MarketPayment.MarketID
JOIN pjt.MarketProductSource ON pjt.Market.MarketID = pjt.MarketProductSource.MarketID
JOIN pjt.MarketVegetarianProduct ON pjt.Market.MarketID = pjt.MarketVegetarianProduct.MarketID
JOIN pjt.MarketAnimalProduct ON pjt.Market.MarketID = pjt.MarketAnimalProduct.MarketID
JOIN pjt.MarketMeat ON pjt.Market.MarketID = pjt.MarketMeat.MarketID
JOIN pjt.MarketBeverage ON pjt.Market.MarketID = pjt.MarketBeverage.MarketID
JOIN pjt.MarketCondiment ON pjt.Market.MarketID = pjt.MarketCondiment.MarketID
JOIN pjt.MarketMiscProduct ON pjt.Market.MarketID = pjt.MarketMiscProduct.MarketID
LEFT JOIN pjt.Payment ON pjt.Payment.PaymentID = pjt.MarketPayment.PaymentID
LEFT JOIN pjt.ProductSource ON pjt.ProductSource.ProductSourceID = pjt.MarketProductSource.ProductSourceID
LEFT JOIN pjt.VegetarianProduct ON pjt.VegetarianProduct.VegetarianProductID = pjt.MarketVegetarianProduct.VegetarianProductID
LEFT JOIN pjt.AnimalProduct ON pjt.AnimalProduct.AnimalProductID = pjt.MarketAnimalProduct.AnimalProductID
LEFT JOIN pjt.Meat ON pjt.Meat.MeatID = pjt.MarketMeat.MeatID
LEFT JOIN pjt.Beverage ON pjt.Beverage.BeverageID = pjt.MarketBeverage.BeverageID
LEFT JOIN pjt.Condiment ON pjt.Condiment.CondimentID = pjt.MarketCondiment.CondimentID
LEFT JOIN pjt.MiscProduct ON pjt.MiscProduct.MiscProductID = pjt.MarketMiscProduct.MiscProductID
GO
-- Market Name, Marketday, Open/Close time, Media, and Last updated
SELECT
	pjt.Market.MarketName AS MarketName
	,pjt.Market.MarketDay AS MarketDay
	,pjt.Market.BusinessOpen AS OpenHours
	,pjt.Market.BusinessClose AS CloseHours
	,pjt.Media.WebsiteURL AS WebsiteURL
	,pjt.Media.FaceBook AS FaceBook
	,pjt.Media.Twitter AS Twitter
	,pjt.MarketInfoUpdate.updateTime AS LastUpdate
FROM pjt.Market
LEFT JOIN pjt.Media ON pjt.Media.MarketID = pjt.Market.MarketID
LEFT JOIN pjt.MarketInfoUpdate ON pjt.MarketInfoUpdate.MarketID = pjt.Market.MarketID
GO
-- Demographic info for each available market (including county and state)
SELECT
	pjt.Market.MarketName AS MarketName
	,pjt.County.County AS County
	,pjt.AddressState.AddressState AS MarketState
	,pjt.Demographic.PerCapita AS PerCapita
	,pjt.Demographic.MedianHouseholdIncome AS MedianHouseholdIncome
	,pjt.Demographic.MedianFamilyIncome AS MedianFamilyIncome
	,pjt.Demographic.AreaPopulation AS AreaPopultion
	,pjt.Demographic.NumberOfHouseholds AS NumberOfHouseholds
FROM pjt.Market
JOIN pjt.MarketState ON pjt.MarketState.MarketID = pjt.Market.MarketID
JOIN pjt.MarketCounty ON pjt.MarketCounty.MarketID = pjt.Market.MarketID
JOIN pjt.MarketDemographic ON pjt.MarketDemographic.MarketID = pjt.Market.MarketID
LEFT JOIN pjt.AddressState ON pjt.AddressState.AddressStateID = pjt.MarketState.AddressStateID
LEFT JOIN pjt.County ON pjt.County.CountyID = pjt.MarketCounty.CountyID
LEFT JOIN pjt.Demographic ON pjt.Demographic.DemographicID = pjt.MarketDemographic.DemographicID
GO



SELECT
	MarketName
	, PayForm
	, ProductSource
	, Veggies
	, AnimalProduce
	, Meats
	, Beverages
	, Condiments
	, MiscProducts
FROM pjt.InspectIncomeCityProducts
LEFT JOIN pjt.MarketMetaData 
ON pjt.MarketMetaData.MarketID = pjt.InspectIncomeCityProducts.MarketID
GO
/* End: Utility Queries */

/* Begin: Data Questions */
-- Question: Based on the information provided are there indeed signs of socioeconomic segregation with respect to marketplace accessibility?

-- Calculate means for the different income metrics
-- PerCapitaAverage: 33253
-- MedianHouseholdIncomeAverage: 61810
-- MedianFamilyIncomeAverage: 76357
-- Get a feel for the economic metrics in the database
SELECT 
	AVG(PerCapita) AS PerCapitaAverage
	, AVG(MedianHouseholdIncome) AS MedianHouseholdIncomeAverage
	, AVG(MedianFamilyIncome) AS MedianFamilyIncomeAverage
FROM pjt.InspectIncomeCityProducts
GO

-- QUESTION: How do types of products available in a given market compare for an area of a higher socio-economic status against an area of a lower socio-economic status?
-- Counts of Veggie Products by City in upper income areas

SELECT 
	City
	, Veggies
	, COUNT(*) AS VeggieProductCount
FROM
	pjt.InspectIncomeCityProducts
WHERE MedianHouseholdIncome > 61810 
GROUP BY
	City
	, Veggies
ORDER BY VeggieProductCount DESC
GO

-- Counts of Animal Produce by City in upper income areas
SELECT 
	City
	, AnimalProduce
	, COUNT(*) AS AnimalProductCount
FROM
	pjt.InspectIncomeCityProducts
WHERE MedianHouseholdIncome > 61810
GROUP BY
	City
	, AnimalProduce
ORDER BY AnimalProductCount DESC
GO

SELECT
	City
	,MedianHouseholdIncome
FROM pjt.InspectIncomeCityProducts
-- Counts of Veggie Products by City in lower income areas
SELECT 
	City
	, Veggies
	, COUNT(*) AS VeggieProductCount
FROM
	pjt.InspectIncomeCityProducts
WHERE MedianHouseholdIncome < 61810 
GROUP BY
	City
	, Veggies
ORDER BY VeggieProductCount DESC
GO

-- QUESTION: There are instances where multiple markets share the same address but occur on different days. Additionally, some markets may perceive to have different address, but share the same geographic coordinates. Are these indeed different markets?
-- Address question of markets sharing addresses:
SELECT 
	StreetAddress
	, COUNT(*) AS MarketAddressShareCounts
FROM pjt.MarketMetaData
GROUP BY StreetAddress
ORDER BY MarketAddressShareCounts DESC
GO

-- If occurences of markets sharing same address appear, user could investigate in the following manner:
SELECT
	MarketName
	, SeasonStartDate
	, SeasonEndDate
	, MarketDay
	, OpenHours
	, CloseHours
FROM pjt.MarketMetaData
WHERE StreetAddress = 'SW Park and Montgomery'
GO

-- Do the Markets really share the same address or is there a mistake? Our resources have provided us with the exact coordinates of each market
-- Any address discrepancies could be seen with a query along the lines as below
SELECT
	StreetAddress
	, Longitude
	, Latitude
	, COUNT(*) AS CoordinateCounts
FROM pjt.MarketMetaData
GROUP BY 
	StreetAddress
	, Longitude
	, Latitude
ORDER BY CoordinateCounts DESC
GO
	
-- QUESTION: How do the market days, as well as operating hours differ when comparing areas of higher socio-economic status against areas of lower socio-economic status?
-- Query market operating hours by city for upper income areas
SELECT 
	pjt.MarketMetaData.City AS City
	, OpenHours
	, CloseHours
	, COUNT(*) AS AreaMarketHoursCount
FROM pjt.MarketMetaData
JOIN pjt.InspectIncomeCityProducts ON pjt.InspectIncomeCityProducts.MarketID = pjt.MarketMetaData.MarketID
WHERE MedianHouseholdIncome > 61810
GROUP BY
	pjt.MarketMetaData.City
	, OpenHours
	, CloseHours
ORDER BY AreaMarketHoursCount DESC
GO

-- Query market operating hours by city for lower income areas
SELECT 
	pjt.MarketMetaData.City AS City
	, OpenHours
	, CloseHours
	, COUNT(*) AS AreaMarketHoursCount
FROM pjt.MarketMetaData
JOIN pjt.InspectIncomeCityProducts ON pjt.InspectIncomeCityProducts.MarketID = pjt.MarketMetaData.MarketID
WHERE MedianHouseholdIncome < 61810
GROUP BY
	pjt.MarketMetaData.City
	, OpenHours
	, CloseHours
ORDER BY AreaMarketHoursCount DESC
GO

-- QUESTION: What�s the relationship between accepted payment types for a given market and the market�s associated demographics?
-- Counts of PayForms by City in upper income areas
SELECT 
	City
	, PayForm
	, COUNT(*) AS PayFormCount
FROM
	pjt.InspectIncomeCityProducts
WHERE MedianHouseholdIncome > 61810 
GROUP BY
	City
	, PayForm
ORDER BY PayFormCount DESC
GO

-- Counts of PayForms by City in lower income areas
SELECT 
	City
	, PayForm
	, COUNT(*) AS PayFormCount
FROM
	pjt.InspectIncomeCityProducts
WHERE MedianHouseholdIncome < 61810 
GROUP BY
	City
	, PayForm
ORDER BY PayFormCount DESC
GO

-- QUESTION: Are areas with higher socio-economic status more likely to have products sourced as �Organic�, �WildHarvested�, or �Prepared� by sellers than areas of lower socio-economic status?
-- Counts of Product Sources by City in upper income areas
SELECT 
	City
	, ProductSource
	, COUNT(*) AS ProductSourceCount
FROM
	pjt.InspectIncomeCityProducts
WHERE MedianHouseholdIncome > 61810 
GROUP BY
	City
	, ProductSource
ORDER BY ProductSourceCount DESC
GO

-- Counts of PayForms by City in lower income areas
SELECT 
	City
	, ProductSource
	, COUNT(*) AS ProductSourceCount
FROM
	pjt.InspectIncomeCityProducts
WHERE MedianHouseholdIncome < 61810 
GROUP BY
	City
	, ProductSource
ORDER BY ProductSourceCount DESC
GO

-- QUESTION: There are many rows that do not offer websites or any form of media. What are the average economic metrics of the areas that do offer these forms of accessibility to communication with markets?
SELECT 
	pjt.MarketMetaData.City AS City
	, AVG(PerCapita) AS PerCapitaAverage
	, AVG(MedianHouseholdIncome) AS MedianHouseholdIncomeAverage
	, AVG(MedianFamilyIncome) AS MedianFamilyIncomeAverage
	, AVG(AreaPopulation) AS AreaPopulationAverage
	, AVG(NumberOfHouseholds) AS NumberOfHouseholdsAverage
FROM pjt.MarketMetaData
JOIN pjt.InspectIncomeCityProducts ON pjt.InspectIncomeCityProducts.MarketID = pjt.MarketMetaData.MarketID
WHERE WebsiteURL = NULL AND
	FaceBook = NULL AND
	Twitter = NULL
GROUP BY
	pjt.MarketMetaData.City
ORDER BY MedianHouseholdIncomeAverage DESC
GO

/* End: Data Questions */