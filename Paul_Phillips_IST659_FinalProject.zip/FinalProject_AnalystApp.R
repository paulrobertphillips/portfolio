" Author: Paul R Phillips
	Course: IST659 M400
	Date: 12/13/2020

	File: App for Analyst Role: Connect to Farmer's Market Database via R

	Description:
		This file contains a sample of how the analyst of the organization
    associated to this project can use the database. From here users can
    connect to the views built (NOT the actual tables)."
##########################################################################
#### Connect to Database
# App for Analyst Role: Connect to Farmer's Market Database via R

# Ready RODBC for use in this script
require(RODBC)
require(dplyr)
require(pivottabler)

# Create a connection to SQL Server using our 64-bit DSN
myconn <- odbcConnect('IST659_FinalProject')

##########################################################################
#### Pull Data from Views
# Market Meta Data View:
sqlSelectStatement <-
  "SELECT 
  	*
  FROM
  	pjt.MarketMetaData
	GO
"

# Send request to the server and store the results in a variable
MarketViewQueryResult <- sqlQuery(myconn, sqlSelectStatement)

# Area Demographics & Market Details View
sqlSelectStatement <-
  "SELECT 
  	*
  FROM
  	pjt.InspectIncomeCityProducts
  GO
"
# Send request to the server and store the results in a variable
IncomeViewQueryResult <- sqlQuery(myconn, sqlSelectStatement)

##########################################################################

#### Question 1
"
-- QUESTION: How do types of products available in a given market compare for an area of a higher socio-economic status against an area of a lower socio-economic status?
-- Counts of Veggie Products by City in upper income areas
"

### Counts of available products by city: higher income
higherIncome <- IncomeViewQueryResult  %>% 
  filter(MedianHouseholdIncome > 61810)

# Veggie Products
pthi <- PivotTable$new()
pthi$addData(higherIncome)
pthi$addColumnDataGroups('Veggies')
pthi$addRowDataGroups('City')
pthi$defineCalculation(calculationName="ProductCounts", summariseExpression="n()")
pthi$renderPivot()

# Animal Products
pthi <- PivotTable$new()
pthi$addData(higherIncome)
pthi$addColumnDataGroups('AnimalProduce')
pthi$addRowDataGroups('City')
pthi$defineCalculation(calculationName="ProductCounts", summariseExpression="n()")
pthi$renderPivot()

# Meat Products
pthi <- PivotTable$new()
pthi$addData(higherIncome)
pthi$addColumnDataGroups('Meats')
pthi$addRowDataGroups('City')
pthi$defineCalculation(calculationName="ProductCounts", summariseExpression="n()")
pthi$renderPivot()

### Counts of available products by city: lower income
lowerIncome <- IncomeViewQueryResult  %>% 
  filter(MedianHouseholdIncome < 61810)

# Veggie Products
pthi <- PivotTable$new()
pthi$addData(lowerIncome)
pthi$addColumnDataGroups('Veggies')
pthi$addRowDataGroups('City')
pthi$defineCalculation(calculationName="ProductCounts", summariseExpression="n()")
pthi$renderPivot()

# Animal Products
pthi <- PivotTable$new()
pthi$addData(lowerIncome)
pthi$addColumnDataGroups('AnimalProduce')
pthi$addRowDataGroups('City')
pthi$defineCalculation(calculationName="ProductCounts", summariseExpression="n()")
pthi$renderPivot()

# Meat Products
pthi <- PivotTable$new()
pthi$addData(lowerIncome)
pthi$addColumnDataGroups('Meats')
pthi$addRowDataGroups('City')
pthi$defineCalculation(calculationName="ProductCounts", summariseExpression="n()")
pthi$renderPivot()

##########################################################################

"
-- QUESTION: There are instances where multiple markets share the same address but occur on different days. Additionally, some markets may perceive to have different address, but share the same geographic coordinates. Are these indeed different markets?
-- Address question of markets sharing addresses:
"
# Inspect Markets sharing same address
MarketViewQueryResult %>% 
  select(StreetAddress) %>% 
  group_by(StreetAddress) %>% 
  summarise(MarketAddressShareCounts = n()) %>% 
  arrange(desc(MarketAddressShareCounts))

"
-- If occurences of markets sharing same address appear, user could investigate in the following manner:
"
# Here all markets and their details sharing this address would appear
MarketViewQueryResult %>% 
  filter(StreetAddress == 'SW Park and Montgomery') %>% 
  select(MarketName,
         SeasonStartDate,
         SeasonEndDate,
         MarketDay,
         OpenHours,
         CloseHours)

"
-- Do the Markets really share the same address or is there a mistake? Our resources have provided us with the exact coordinates of each market
-- Any address discrepancies could be seen with a query along the lines as below

"
MarketViewQueryResult %>% 
  select(StreetAddress,
         Longitude,
         Latitude) %>% 
  group_by(StreetAddress,
           Longitude,
           Latitude) %>% 
  summarise(CoordinateCounts = n()) %>% 
  arrange(desc(CoordinateCounts))

##########################################################################

"
-- QUESTION: How do the market days, as well as operating hours differ when comparing areas of higher socio-economic status against areas of lower socio-economic status?
-- Query market operating hours by city for upper income areas
"
# Extract counts of operating hour combinations in areas of higher income
MarketViewQueryResult %>% 
  left_join(IncomeViewQueryResult, by='MarketID') %>%
  filter(MedianHouseholdIncome > 61810) %>% 
  select(City=City.x, OpenHours, CloseHours) %>% 
  group_by(City,
           OpenHours,
           CloseHours) %>%
  summarise(AreaMarketHoursCount = n()) %>% 
  arrange(desc(AreaMarketHoursCount))
  
"
-- Query market operating hours by city for lower income areas
"
# Extract counts of operating hour combinations in areas of lower income
MarketViewQueryResult %>% 
  left_join(IncomeViewQueryResult, by='MarketID') %>%
  filter(MedianHouseholdIncome < 61810) %>% 
  select(City=City.x, OpenHours, CloseHours) %>% 
  group_by(City,
           OpenHours,
           CloseHours) %>%
  summarise(AreaMarketHoursCount = n()) %>% 
  arrange(desc(AreaMarketHoursCount))

##########################################################################

"
-- QUESTION: What’s the relationship between accepted payment types for a given market and the market’s associated demographics?
-- Counts of PayForms by City in upper income areas
"
# Counts of PayForms by City in upper income areas
IncomeViewQueryResult %>% 
  filter(MedianHouseholdIncome > 61810) %>% 
  select(City, PayForm) %>% 
  group_by(City, PayForm) %>% 
  summarise(PayFormCount = n()) %>% 
  arrange(desc(PayFormCount))

"
-- Counts of PayForms by City in lower income areas
"
IncomeViewQueryResult %>% 
  filter(MedianHouseholdIncome < 61810) %>% 
  select(City, PayForm) %>% 
  group_by(City, PayForm) %>% 
  summarise(PayFormCount = n()) %>% 
  arrange(desc(PayFormCount))

##########################################################################

"
-- QUESTION: Are areas with higher socio-economic status more likely to have products sourced as “Organic”, “WildHarvested”, or “Prepared” by sellers than areas of lower socio-economic status?
-- Counts of Product Sources by City in upper income areas
"
IncomeViewQueryResult %>% 
  filter(MedianHouseholdIncome > 61810) %>% 
  select(City, ProductSource) %>% 
  group_by(City, ProductSource) %>% 
  summarise(ProductSourceCount = n()) %>% 
  arrange(desc(ProductSourceCount))

"
-- Counts of Product Sources by City in upper income areas
"
IncomeViewQueryResult %>% 
  filter(MedianHouseholdIncome < 61810) %>% 
  select(City, ProductSource) %>% 
  group_by(City, ProductSource) %>% 
  summarise(ProductSourceCount = n()) %>% 
  arrange(desc(ProductSourceCount))

##########################################################################

"
-- QUESTION: There are many rows that do not offer websites or any form of media. What are the average economic metrics of the areas that do offer these forms of accessibility to communication with markets?
"

# If such scenarios exist in the database this command could answer the question
MarketViewQueryResult %>% 
  left_join(IncomeViewQueryResult, by='MarketID') %>% 
  filter(is.null(WebsiteURL) &
           is.null(FaceBook) &
           is.null(Twitter)) %>% 
  select(City=City.x,
         PerCapita,
         MedianHouseholdIncome,
         MedianFamilyIncome,
         AreaPopulation,
         NumberOfHouseholds) %>% 
  group_by(City) %>% 
  summarise(PerCapitaAverage = mean(PerCapita),
            MedianHouseholdIncomeAverage = mean(MedianHouseholdIncome),
            MedianFamilyIncomeAverage = mean(MedianFamilyIncome),
            AreaPopulationAverage = mean(AreaPopulation),
            NumberOfHouseholdsAverage = mean(NumberOfHouseholds)) %>% 
  arrange(desc(MedianHouseholdIncomeAverage))
  
##########################################################################

# Close all connections
odbcCloseAll()
