world_population = {'Spain':'ES',
			   'Germany':'DE',
			   'Russia':'RUS',
			   'China':'CN',
			   'Mexico':'MX',
			   'Venezuela':'VE',
			   'Portugal':'PT'}