"""
Note: The purpose of this document is to illustrate the capabilities a program can have when a developer implements a particular 
      a dynamic interaction between the user and the program specifically in regards to updating key-value paired dictionaries that
      get used for recoding particular columns.There are times in analytics where new categorical levels may arise in new incoming 
      data. It's important to design a program that offers enough flexibility to catch this. A developer nor the program will not be 
      able to account for future recoding needs, so why not make this the responsibility of the user?

Steps: Create a simple dictionary in a separate file. Set the keys to reference raw values of a column and have the values of the dictionary 
       refer to the values the column needs to be recoded into. I recommend storing as a .py file but .txt works fine too.
       Storing the dictionary in a separate file will allow you to save changes made for future reruns of this program. The pieces needed here 
       include importing the needed dictionary, the data, and to set controls such that the column involved in the process will always be in the
       same format as the associated dictionary keys. Just assume that incoming data may be coming from a new source, or the formatting could change
       so that the keys will always be relevant.
"""
# Needed libraries
import pandas as pd
import numpy as np
import warnings
import os
import timeit
from tkinter import *
from tkinter import filedialog
from zipfile import ZipFile
import contextlib

# tic = timeit.default_timer()
# ... some code here ...
# toc = timeit.default_timer()
# print((toc - tic)/60)

### Set directory paths


### Set working directory (points to location of dictionary)
# Grab zip directory
root = Tk()

currdir = os.getcwd()
zipFolderExample_dir = filedialog.askdirectory(parent=root,
                                               initialdir=currdir,
                                               title='Please select folder containing sample zip file') + '/'

# Remove tkinter windows
root.destroy()

# Change working directory to changed directory:
os.chdir(zipFolderExample_dir)

# Suppress warning messages
warnings.filterwarnings("ignore")

# Scan for zip file
for fname in os.listdir(zipFolderExample_dir):
    # If current iteration is a subfolder, skip
    if 'population_data.csv' in fname:
        
        ### Import data
        populationDF = pd.read_csv(zipFolderExample_dir+fname)
        
        # Try to import 'WORLD POPULATION'
        # If not available, skip and for loop will return it's importation
        try:
            from WORLD_POPULATION import world_population
        except:
            continue
        
    elif '.zip' in fname:
        # Extract data file
        fh = open(zipFolderExample_dir+fname, 'rb')
        z = ZipFile(fh)
        dictionaryFile = [file for file in z.namelist() if file == 'WORLD_POPULATION.py']
        dataFile = [file for file in z.namelist() if file == 'population_data.csv']
        
        # Import associated dictionary
        exec(z.open(dictionaryFile[0]).read())
        
        ### Import data
        populationDF = pd.read_csv(z.open(dataFile[0]))
        
        # Close zip file
        fh.close()
    else:
        continue
    
print("List of Countries in File (Before Recode): {}".format(populationDF.country.unique()))

### Perform needed cleansing

######################################################################################################
#### Begin dynamic process

# Initial check for new levels
world_population_update_needed = all(elem in list(world_population.keys()) for elem in list(populationDF.country.unique()))

# Opt1: Quick check for new techs
if (world_population_update_needed == False):

    # Store new levels in iterable object
    values = [populationDF.country.unique()[i] for i in range(0, len(populationDF.country.unique())) if populationDF.country.unique()[i] not in list(world_population.keys())]

    # Opt2: Grab only new values otherwise recode
    # Note: <dictionary_name> refers to imported dictionary
    if len(values) == 0:
        populationDF["country"] = populationDF.country.map(world_population)
    else:
        print("\n*****Updating Imported Dictionary in Progress*****")
        # Iterate through each new level to give user opportunity to recode
        for value in values:
            name_created = 0
            # User can only break loop if valid input is provided
            while name_created < 1:
                action_inquiry = input((value+" has not yet been recoded, would\nyou like to abbreviate the name?\nEnter (yes/no): "))
                action_inquiry = action_inquiry.lower().replace(" ", "")
                if "yes" in action_inquiry:
                    name_change = input("Please enter new name\nNOTE\nJust hit 'Enter' if level should be blank: ").upper().replace(" ", "")
                    name_created += 1
                else:
                    print("\nWARNING:\nResponse should be 'yes' or 'no'\nReceived: {}".format(action_inquiry))
            
            name_validated = 0
            # User can only break loop by signing off on official name for tech (i.e. entering 'yes')
            while name_validated < 1:
                action_inquiry = input(("You would like to recode {} with {}?\nEnter (yes/no): ".format(value, name_change)))
                action_inquiry = action_inquiry.lower().replace(" ", "")
                if "yes" in action_inquiry:
                    # Update dictionary
                    world_population[value] = name_change

                    # Update dictionary in file:
                    outFile = open("WORLD_POPULATION.py", "w")
                    outFile.writelines(("world_population = "+ str(world_population).replace(" ", "").replace(",", ",\n\t\t\t   ")))
                    outFile.close()

                    # Close loop: name has been validated:
                    name_validated += 1
                elif "no" in action_inquiry:
                    name_change = input("Please enter new name\nNOTE\nJust hit 'Enter' if level should be blank: ").upper().replace(" ", "")
                else:
                    print("\nWARNING:\nResponse should be 'yes' or 'no'\nReceived: {}".format(action_inquiry))
            
        # Recode new values:
        populationDF["country"] = populationDF.country.map(world_population)

        print("\n*****End of Imported Dictionary Update*****\n")

else:
    # If there are no new levels simply use existing imported dictionary
    populationDF["country"] = populationDF.country.map(world_population)

print("List of Countries in File (After Recode): {}".format(populationDF.country.unique()))
print("Average population across countries: {}".format(populationDF.population.mean()))